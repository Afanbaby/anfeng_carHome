package com.lanou3g.an.carhome.articleNestingFragment;

import com.lanou3g.an.carhome.R;
import com.lanou3g.an.carhome.beas.BaseFragment;

/**
 * Created by anfeng on 16/5/9.
 *  推荐中的导购
 */
public class ShoppingFragment extends BaseFragment {
    @Override
    public int setLayout() {
        return R.layout.fragment_shopping;
    }

    @Override
    protected void initView() {

    }

    @Override
    protected void initData() {

    }
}
