package com.lanou3g.an.carhome.my.login;

import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.lanou3g.an.carhome.R;
import com.lanou3g.an.carhome.beas.BaseActivity;
import com.lanou3g.an.carhome.my.register.RegisterActivity;

/**
 * Created by anfeng on 16/5/29.
 * 登录页面的Activity
 */
public class LoginActivity extends BaseActivity implements View.OnClickListener {

    private TextView registerTv, returnTv;
    private Button loginBtn;
    private EditText userEt;

    @Override
    protected int getLayout() {
        return R.layout.activity_login;
    }

    @Override
    protected void initView() {
        registerTv = bindView(R.id.activity_login_register);
        registerTv.setOnClickListener(this);
        returnTv = bindView(R.id.activity_login_return);
        returnTv.setOnClickListener(this);
        loginBtn = bindView(R.id.activity_login_btn);
        loginBtn.setOnClickListener(this);
        userEt = bindView(R.id.activity_login_user_et);
    }

    @Override
    protected void initData() {

    }

    //注册的点击事件
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.activity_login_register:
                Intent intent = new Intent();
                intent.setClass(this, RegisterActivity.class);
                startActivity(intent);
                break;
            case R.id.activity_login_return:
                finish();
                break;
            case R.id.activity_login_btn:
                if (userEt.getText().length() == 0) {
                    Toast.makeText(LoginActivity.this, "用户名不能为空", Toast.LENGTH_SHORT).show();
                } else {
                    String userName = userEt.getText().toString();
                    finish();
                }
                break;
        }
    }
}
