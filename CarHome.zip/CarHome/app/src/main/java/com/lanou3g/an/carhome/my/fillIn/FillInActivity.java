package com.lanou3g.an.carhome.my.fillIn;

import com.lanou3g.an.carhome.beas.BaseActivity;

/**
 * Created by anfeng on 16/5/30.
 */
public class FillInActivity extends BaseActivity {

    @Override
    protected int getLayout() {
        return 0;
    }

    @Override
    protected void initView() {

    }

    @Override
    protected void initData() {

    }
}
