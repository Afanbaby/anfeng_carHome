package com.lanou3g.an.carhome.eventBus;

/**
 * Created by anfeng on 16/5/20.
 */
public class DataBean {
    private int type;

    public DataBean(int type) {
        this.type = type;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }
}
