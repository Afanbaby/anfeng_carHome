package com.lanou3g.an.carhome.articleNestingFragment.journalism;

import java.util.List;

/**
 * Created by anfeng on 16/5/14.
 */
public class JournalismBean {

    /**
     * rowcount : 31869
     * isloadmore : true
     * headlineinfo : {}
     * focusimg : []
     * newslist : [{"dbid":0,"id":888505,"title":"两款车型 江铃福特途睿欧5月19日上市","mediatype":0,"type":"新闻中心","time":"2016-05-14","intacttime":"2016/5/14 13:46:46","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g12/M07/7E/77/400x300_0_autohomecar__wKgH4lc2u4yAN9EEAAHV4PAcK5s863.jpg","replycount":72,"pagecount":1,"jumppage":1,"lasttime":"20160514134646888505","newstype":0,"updatetime":"20160514134555","coverimages":[]},{"dbid":0,"id":888504,"title":"国内专属 奥迪A6L e-tron或11月上市","mediatype":0,"type":"新闻中心","time":"2016-05-14","intacttime":"2016/5/14 12:58:17","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g10/M08/7C/85/400x300_0_autohomecar__wKjBzVc2pV-AZxaSAAHLMLeJVbA708.jpg","replycount":184,"pagecount":1,"jumppage":1,"lasttime":"20160514125817888504","newstype":0,"updatetime":"20160514125700","coverimages":[]},{"dbid":0,"id":888501,"title":"沃尔沃S90/S90L或分别于7月/11月上市","mediatype":0,"type":"新闻中心","time":"2016-05-14","intacttime":"2016/5/14 10:17:00","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g8/M15/7F/41/400x300_0_autohomecar__wKgH3lc2DMKANmKNAAFVPO4BzLA960.jpg","replycount":835,"pagecount":1,"jumppage":1,"lasttime":"20160514101700888501","newstype":0,"updatetime":"20160514012815","coverimages":[]},{"dbid":0,"id":888503,"title":"高性能版本 捷豹F-PACE SVR假想图曝光","mediatype":0,"type":"新闻中心","time":"2016-05-14","intacttime":"2016/5/14 9:22:57","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g18/M11/7B/F0/400x300_0_autohomecar__wKgH2Vc2kxWAPi8xAAG7TcTeNGQ557.jpg","replycount":72,"pagecount":1,"jumppage":1,"lasttime":"20160514092257888503","newstype":0,"updatetime":"20160514105415","coverimages":[]},{"dbid":0,"id":888500,"title":"最快2016年底发布 新奥迪S5效果图曝光","mediatype":0,"type":"新闻中心","time":"2016-05-14","intacttime":"2016/5/14 9:10:00","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g14/M05/7B/49/400x300_0_autohomecar__wKgH1Vc2CX6AWzS-AAEPJAr5fwQ779.jpg","replycount":263,"pagecount":1,"jumppage":1,"lasttime":"20160514091000888500","newstype":0,"updatetime":"20160514011120","coverimages":[]},{"dbid":0,"id":888499,"title":"或2017年3月亮相 奥迪新一代A8谍照首曝","mediatype":0,"type":"新闻中心","time":"2016-05-14","intacttime":"2016/5/14 6:05:00","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g9/M15/7F/CA/400x300_0_autohomecar__wKgH31c2AnGAZh1fAAHnP_7aYhk967.jpg","replycount":410,"pagecount":1,"jumppage":1,"lasttime":"20160514060500888499","newstype":0,"updatetime":"20160514003758","coverimages":[]},{"dbid":0,"id":888496,"title":"配2.0T发动机 捷豹F-TYPE将增入门车型","mediatype":0,"type":"新闻中心","time":"2016-05-14","intacttime":"2016/5/14 6:05:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g18/M0E/7B/9A/400x300_0_autohomecar__wKgH2Vc14WyARfXHAAG42Ji6l9w380.jpg","replycount":244,"pagecount":1,"jumppage":1,"lasttime":"20160514060500888496","newstype":0,"updatetime":"20160513221947","coverimages":[]},{"dbid":0,"id":888490,"title":"尺寸加大/油耗持平 上汽通用推科鲁兹XL","mediatype":0,"type":"新闻中心","time":"2016-05-14","intacttime":"2016/5/14 6:00:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g13/M02/7B/F9/400x300_0_autohomecar__wKgH1Fc1nPqAaS0PAAFYyCyPN_8865.jpg","replycount":636,"pagecount":1,"jumppage":1,"lasttime":"20160514060000888490","newstype":0,"updatetime":"20160513184153","coverimages":[]},{"dbid":0,"id":888451,"title":"君威降3.7万 本周合资中型车降价排行","mediatype":0,"type":"新闻中心","time":"2016-05-14","intacttime":"2016/5/14 0:00:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g13/M08/7C/1A/400x300_0_autohomecar__wKgH1Fc1vh6Af09SAAF2o7kVrDY769.jpg","replycount":516,"pagecount":3,"jumppage":1,"lasttime":"20160514000000888451","newstype":0,"updatetime":"20160514143446","coverimages":[]},{"dbid":0,"id":888491,"title":"或即将进入国内 曝高尔夫Alltrack信息","mediatype":0,"type":"新闻中心","time":"2016-05-13","intacttime":"2016/5/13 20:06:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g17/M14/76/5A/400x300_0_autohomecar__wKjBxlc1otuAElbUAAFKflthnlQ186.jpg","replycount":504,"pagecount":1,"jumppage":1,"lasttime":"20160513200600888491","newstype":0,"updatetime":"20160513175410","coverimages":[]},{"dbid":0,"id":888493,"title":"或配6AT 曝东风标致2008 1.2T动力信息","mediatype":0,"type":"新闻中心","time":"2016-05-13","intacttime":"2016/5/13 20:05:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g13/M0E/7C/B2/400x300_0_autohomecar__wKgH41c1q5CAPMh1AAGduMe1JIs481.jpg","replycount":422,"pagecount":1,"jumppage":1,"lasttime":"20160513200500888493","newstype":0,"updatetime":"20160513182632","coverimages":[]},{"dbid":0,"id":888485,"title":"售10.98万元 北京现代领动增1.6L新车型","mediatype":0,"type":"新闻中心","time":"2016-05-13","intacttime":"2016/5/13 15:05:14","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g18/M0D/7B/20/400x300_0_autohomecar__wKgH2Vc1e02AbRkRAAHIViti3tk872.jpg","replycount":557,"pagecount":1,"jumppage":1,"lasttime":"20160513150514888485","newstype":0,"updatetime":"20160513150431","coverimages":[]},{"dbid":0,"id":888476,"title":"2年出3款廉价SUV 现代-起亚发力SUV市场","mediatype":0,"type":"新闻中心","time":"2016-05-13","intacttime":"2016/5/13 13:51:31","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g16/M15/7B/84/400x300_0_autohomecar__wKgH5lc1aF6AMGH9AAD6iT2nSKI462.jpg","replycount":843,"pagecount":1,"jumppage":1,"lasttime":"20160513135131888476","newstype":0,"updatetime":"20160513154435","coverimages":[]},{"dbid":0,"id":888478,"title":"共涉44096辆 雪佛兰召回创酷/爱唯欧","mediatype":0,"type":"新闻中心","time":"2016-05-13","intacttime":"2016/5/13 13:51:29","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g13/M02/7B/AA/400x300_0_autohomecar__wKjBylc1abOAeVGvAAFM_rEtQbs293.jpg","replycount":240,"pagecount":1,"jumppage":1,"lasttime":"20160513135129888478","newstype":0,"updatetime":"20160513135026","coverimages":[]},{"dbid":0,"id":888477,"title":"纪念建厂50年 路特斯推Evora 400特别版","mediatype":0,"type":"新闻中心","time":"2016-05-13","intacttime":"2016/5/13 13:50:39","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g10/M09/7B/77/400x300_0_autohomecar__wKjBzVc1YRuAC9pvAAG1cICi4rE205.jpg","replycount":151,"pagecount":1,"jumppage":1,"lasttime":"20160513135039888477","newstype":0,"updatetime":"20160513133754","coverimages":[]},{"dbid":0,"id":888475,"title":"带自动驾驶功能 新奥迪A8于2017年上市","mediatype":0,"type":"新闻中心","time":"2016-05-13","intacttime":"2016/5/13 13:22:21","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g19/M0D/5D/48/400x300_0_autohomecar__wKjBxFc1Y8mAEhqbAAD-wk8wjbc119.jpg","replycount":514,"pagecount":1,"jumppage":1,"lasttime":"20160513132221888475","newstype":0,"updatetime":"20160513131955","coverimages":[]},{"dbid":0,"id":888473,"title":"5月20日上市 北汽绅宝X35或售6万元起","mediatype":0,"type":"新闻中心","time":"2016-05-13","intacttime":"2016/5/13 11:33:58","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g17/M0C/76/F4/400x300_0_autohomecar__wKgH51c1SU6AdLSTAAIL6E3IwQc356.jpg","replycount":486,"pagecount":1,"jumppage":1,"lasttime":"20160513113358888473","newstype":0,"updatetime":"20160513114730","coverimages":[]},{"dbid":0,"id":888472,"title":"共享技术资源 日产收购三菱汽车34%股份","mediatype":0,"type":"新闻中心","time":"2016-05-13","intacttime":"2016/5/13 10:48:33","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g9/M0F/7E/DF/400x300_0_autohomecar__wKgH31c1QBWAE0zdAAD8vFDqeuU125.jpg","replycount":513,"pagecount":1,"jumppage":1,"lasttime":"20160513104833888472","newstype":0,"updatetime":"20160513104709","coverimages":[]},{"dbid":0,"id":888470,"title":"售8.88-9.68万元 哈弗H2舒适版车型上市","mediatype":0,"type":"新闻中心","time":"2016-05-13","intacttime":"2016/5/13 10:35:34","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g23/M02/5D/CF/400x300_0_autohomecar__wKgFXFc1PA6AS0VOAAE784n3Qxw700.jpg","replycount":865,"pagecount":1,"jumppage":1,"lasttime":"20160513103534888470","newstype":0,"updatetime":"20160513103505","coverimages":[]},{"dbid":0,"id":888469,"title":"富士重工将于明年4月更名\u201c斯巴鲁\u201d","mediatype":0,"type":"新闻中心","time":"2016-05-13","intacttime":"2016/5/13 9:34:59","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g9/M06/7E/38/400x300_0_autohomecar__wKgH0Fc1LOCAVImWAAA_pTiSi10641.jpg","replycount":700,"pagecount":1,"jumppage":1,"lasttime":"20160513093459888469","newstype":0,"updatetime":"20160513092639","coverimages":[]},{"dbid":0,"id":888467,"title":"或为XC40雏形 曝沃尔沃新概念车预告图","mediatype":0,"type":"新闻中心","time":"2016-05-13","intacttime":"2016/5/13 9:20:46","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g13/M0E/7B/F5/400x300_0_autohomecar__wKgH41c1IOKAc1SRAADLY3eA-Jg494.jpg","replycount":445,"pagecount":1,"jumppage":1,"lasttime":"20160513092046888467","newstype":0,"updatetime":"20160513091902","coverimages":[]},{"dbid":0,"id":888466,"title":"或2016年底亮相 雪佛兰全新Equinox谍照","mediatype":0,"type":"新闻中心","time":"2016-05-13","intacttime":"2016/5/13 7:54:25","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g11/M01/7B/21/400x300_0_autohomecar__wKgH4Vc1FzCARq7UAAFMw1J2e7I446.jpg","replycount":109,"pagecount":1,"jumppage":1,"lasttime":"20160513075425888466","newstype":0,"updatetime":"20160513075219","coverimages":[]},{"dbid":0,"id":888461,"title":"或配1.6T高功率发动机 现代i30 N新消息","mediatype":0,"type":"新闻中心","time":"2016-05-13","intacttime":"2016/5/13 6:05:00","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g8/M14/7D/C3/400x300_0_autohomecar__wKgH3lc0VwCABIaZAAGfD0gezN4761.jpg","replycount":246,"pagecount":1,"jumppage":1,"lasttime":"20160513060500888461","newstype":0,"updatetime":"20160512181340","coverimages":[]},{"dbid":0,"id":888458,"title":"或2017年初亮相 曝新款福特翼搏假想图","mediatype":0,"type":"新闻中心","time":"2016-05-13","intacttime":"2016/5/13 6:04:00","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g16/M12/7A/82/400x300_0_autohomecar__wKjBx1c0Tb2ADt3lAAGILbptsXE522.jpg","replycount":346,"pagecount":1,"jumppage":1,"lasttime":"20160513060400888458","newstype":0,"updatetime":"20160512173516","coverimages":[]},{"dbid":0,"id":888459,"title":"斯巴鲁发布LEVORG STi量产版车型预告图","mediatype":0,"type":"新闻中心","time":"2016-05-13","intacttime":"2016/5/13 6:00:00","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g10/M09/7A/D2/400x300_0_autohomecar__wKgH4Fc0TeKAZoiNAACr0ZAtvbY583.jpg","replycount":231,"pagecount":1,"jumppage":1,"lasttime":"20160513060000888459","newstype":0,"updatetime":"20160512175103","coverimages":[]},{"dbid":0,"id":888450,"title":"变相加价很普遍 全新思域四地购车调查","mediatype":0,"type":"新闻中心","time":"2016-05-13","intacttime":"2016/5/13 0:00:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g15/M02/78/61/400x300_0_autohomecar__wKgH5Vc0Ug-AF3fbAAGU_G9lsOM674.jpg","replycount":4406,"pagecount":3,"jumppage":1,"lasttime":"20160513000000888450","newstype":0,"updatetime":"20160513170622","coverimages":[]},{"dbid":0,"id":888462,"title":"销量不佳是主因 丰田FJ 酷路泽8月停产","mediatype":0,"type":"新闻中心","time":"2016-05-12","intacttime":"2016/5/12 20:10:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g14/M14/7B/77/400x300_0_autohomecar__wKgH5Fc0WLmAMXC_AAHrRpjm8v8358.jpg","replycount":1125,"pagecount":1,"jumppage":1,"lasttime":"20160512201000888462","newstype":0,"updatetime":"20160513163635","coverimages":[]},{"dbid":0,"id":888455,"title":"增加电子手刹 新款雪铁龙C4L实车曝光","mediatype":0,"type":"新闻中心","time":"2016-05-12","intacttime":"2016/5/12 20:05:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g15/M02/7B/AE/400x300_0_autohomecar__wKgH1lc0P7KAd-dSAAFIRNLgU8w586.jpg","replycount":701,"pagecount":1,"jumppage":1,"lasttime":"20160512200500888455","newstype":0,"updatetime":"20160512164733","coverimages":[]},{"dbid":0,"id":888457,"title":"搭载1.5T/2.0T 汉腾SUV动力信息曝光","mediatype":0,"type":"新闻中心","time":"2016-05-12","intacttime":"2016/5/12 20:01:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g13/M05/7A/BD/400x300_0_autohomecar__wKjBylc0P9OATHpkAAE9BLumDEE964.jpg","replycount":441,"pagecount":1,"jumppage":1,"lasttime":"20160512200100888457","newstype":0,"updatetime":"20160512164559","coverimages":[]},{"dbid":0,"id":888454,"title":"1.5T+5MT 野马T70升级版5月29日发布","mediatype":0,"type":"新闻中心","time":"2016-05-12","intacttime":"2016/5/12 17:14:22","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g11/M11/7A/93/400x300_0_autohomecar__wKgH4Vc0RH-AYtGTAAFWiU6edNg918.jpg","replycount":1376,"pagecount":1,"jumppage":1,"lasttime":"20160512171422888454","newstype":0,"updatetime":"20160513180508","coverimages":[]}]
     * topnewsinfo : {}
     */

    private ResultBean result;
    /**
     * result : {"rowcount":31869,"isloadmore":true,"headlineinfo":{},"focusimg":[],"newslist":[{"dbid":0,"id":888505,"title":"两款车型 江铃福特途睿欧5月19日上市","mediatype":0,"type":"新闻中心","time":"2016-05-14","intacttime":"2016/5/14 13:46:46","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g12/M07/7E/77/400x300_0_autohomecar__wKgH4lc2u4yAN9EEAAHV4PAcK5s863.jpg","replycount":72,"pagecount":1,"jumppage":1,"lasttime":"20160514134646888505","newstype":0,"updatetime":"20160514134555","coverimages":[]},{"dbid":0,"id":888504,"title":"国内专属 奥迪A6L e-tron或11月上市","mediatype":0,"type":"新闻中心","time":"2016-05-14","intacttime":"2016/5/14 12:58:17","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g10/M08/7C/85/400x300_0_autohomecar__wKjBzVc2pV-AZxaSAAHLMLeJVbA708.jpg","replycount":184,"pagecount":1,"jumppage":1,"lasttime":"20160514125817888504","newstype":0,"updatetime":"20160514125700","coverimages":[]},{"dbid":0,"id":888501,"title":"沃尔沃S90/S90L或分别于7月/11月上市","mediatype":0,"type":"新闻中心","time":"2016-05-14","intacttime":"2016/5/14 10:17:00","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g8/M15/7F/41/400x300_0_autohomecar__wKgH3lc2DMKANmKNAAFVPO4BzLA960.jpg","replycount":835,"pagecount":1,"jumppage":1,"lasttime":"20160514101700888501","newstype":0,"updatetime":"20160514012815","coverimages":[]},{"dbid":0,"id":888503,"title":"高性能版本 捷豹F-PACE SVR假想图曝光","mediatype":0,"type":"新闻中心","time":"2016-05-14","intacttime":"2016/5/14 9:22:57","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g18/M11/7B/F0/400x300_0_autohomecar__wKgH2Vc2kxWAPi8xAAG7TcTeNGQ557.jpg","replycount":72,"pagecount":1,"jumppage":1,"lasttime":"20160514092257888503","newstype":0,"updatetime":"20160514105415","coverimages":[]},{"dbid":0,"id":888500,"title":"最快2016年底发布 新奥迪S5效果图曝光","mediatype":0,"type":"新闻中心","time":"2016-05-14","intacttime":"2016/5/14 9:10:00","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g14/M05/7B/49/400x300_0_autohomecar__wKgH1Vc2CX6AWzS-AAEPJAr5fwQ779.jpg","replycount":263,"pagecount":1,"jumppage":1,"lasttime":"20160514091000888500","newstype":0,"updatetime":"20160514011120","coverimages":[]},{"dbid":0,"id":888499,"title":"或2017年3月亮相 奥迪新一代A8谍照首曝","mediatype":0,"type":"新闻中心","time":"2016-05-14","intacttime":"2016/5/14 6:05:00","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g9/M15/7F/CA/400x300_0_autohomecar__wKgH31c2AnGAZh1fAAHnP_7aYhk967.jpg","replycount":410,"pagecount":1,"jumppage":1,"lasttime":"20160514060500888499","newstype":0,"updatetime":"20160514003758","coverimages":[]},{"dbid":0,"id":888496,"title":"配2.0T发动机 捷豹F-TYPE将增入门车型","mediatype":0,"type":"新闻中心","time":"2016-05-14","intacttime":"2016/5/14 6:05:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g18/M0E/7B/9A/400x300_0_autohomecar__wKgH2Vc14WyARfXHAAG42Ji6l9w380.jpg","replycount":244,"pagecount":1,"jumppage":1,"lasttime":"20160514060500888496","newstype":0,"updatetime":"20160513221947","coverimages":[]},{"dbid":0,"id":888490,"title":"尺寸加大/油耗持平 上汽通用推科鲁兹XL","mediatype":0,"type":"新闻中心","time":"2016-05-14","intacttime":"2016/5/14 6:00:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g13/M02/7B/F9/400x300_0_autohomecar__wKgH1Fc1nPqAaS0PAAFYyCyPN_8865.jpg","replycount":636,"pagecount":1,"jumppage":1,"lasttime":"20160514060000888490","newstype":0,"updatetime":"20160513184153","coverimages":[]},{"dbid":0,"id":888451,"title":"君威降3.7万 本周合资中型车降价排行","mediatype":0,"type":"新闻中心","time":"2016-05-14","intacttime":"2016/5/14 0:00:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g13/M08/7C/1A/400x300_0_autohomecar__wKgH1Fc1vh6Af09SAAF2o7kVrDY769.jpg","replycount":516,"pagecount":3,"jumppage":1,"lasttime":"20160514000000888451","newstype":0,"updatetime":"20160514143446","coverimages":[]},{"dbid":0,"id":888491,"title":"或即将进入国内 曝高尔夫Alltrack信息","mediatype":0,"type":"新闻中心","time":"2016-05-13","intacttime":"2016/5/13 20:06:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g17/M14/76/5A/400x300_0_autohomecar__wKjBxlc1otuAElbUAAFKflthnlQ186.jpg","replycount":504,"pagecount":1,"jumppage":1,"lasttime":"20160513200600888491","newstype":0,"updatetime":"20160513175410","coverimages":[]},{"dbid":0,"id":888493,"title":"或配6AT 曝东风标致2008 1.2T动力信息","mediatype":0,"type":"新闻中心","time":"2016-05-13","intacttime":"2016/5/13 20:05:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g13/M0E/7C/B2/400x300_0_autohomecar__wKgH41c1q5CAPMh1AAGduMe1JIs481.jpg","replycount":422,"pagecount":1,"jumppage":1,"lasttime":"20160513200500888493","newstype":0,"updatetime":"20160513182632","coverimages":[]},{"dbid":0,"id":888485,"title":"售10.98万元 北京现代领动增1.6L新车型","mediatype":0,"type":"新闻中心","time":"2016-05-13","intacttime":"2016/5/13 15:05:14","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g18/M0D/7B/20/400x300_0_autohomecar__wKgH2Vc1e02AbRkRAAHIViti3tk872.jpg","replycount":557,"pagecount":1,"jumppage":1,"lasttime":"20160513150514888485","newstype":0,"updatetime":"20160513150431","coverimages":[]},{"dbid":0,"id":888476,"title":"2年出3款廉价SUV 现代-起亚发力SUV市场","mediatype":0,"type":"新闻中心","time":"2016-05-13","intacttime":"2016/5/13 13:51:31","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g16/M15/7B/84/400x300_0_autohomecar__wKgH5lc1aF6AMGH9AAD6iT2nSKI462.jpg","replycount":843,"pagecount":1,"jumppage":1,"lasttime":"20160513135131888476","newstype":0,"updatetime":"20160513154435","coverimages":[]},{"dbid":0,"id":888478,"title":"共涉44096辆 雪佛兰召回创酷/爱唯欧","mediatype":0,"type":"新闻中心","time":"2016-05-13","intacttime":"2016/5/13 13:51:29","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g13/M02/7B/AA/400x300_0_autohomecar__wKjBylc1abOAeVGvAAFM_rEtQbs293.jpg","replycount":240,"pagecount":1,"jumppage":1,"lasttime":"20160513135129888478","newstype":0,"updatetime":"20160513135026","coverimages":[]},{"dbid":0,"id":888477,"title":"纪念建厂50年 路特斯推Evora 400特别版","mediatype":0,"type":"新闻中心","time":"2016-05-13","intacttime":"2016/5/13 13:50:39","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g10/M09/7B/77/400x300_0_autohomecar__wKjBzVc1YRuAC9pvAAG1cICi4rE205.jpg","replycount":151,"pagecount":1,"jumppage":1,"lasttime":"20160513135039888477","newstype":0,"updatetime":"20160513133754","coverimages":[]},{"dbid":0,"id":888475,"title":"带自动驾驶功能 新奥迪A8于2017年上市","mediatype":0,"type":"新闻中心","time":"2016-05-13","intacttime":"2016/5/13 13:22:21","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g19/M0D/5D/48/400x300_0_autohomecar__wKjBxFc1Y8mAEhqbAAD-wk8wjbc119.jpg","replycount":514,"pagecount":1,"jumppage":1,"lasttime":"20160513132221888475","newstype":0,"updatetime":"20160513131955","coverimages":[]},{"dbid":0,"id":888473,"title":"5月20日上市 北汽绅宝X35或售6万元起","mediatype":0,"type":"新闻中心","time":"2016-05-13","intacttime":"2016/5/13 11:33:58","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g17/M0C/76/F4/400x300_0_autohomecar__wKgH51c1SU6AdLSTAAIL6E3IwQc356.jpg","replycount":486,"pagecount":1,"jumppage":1,"lasttime":"20160513113358888473","newstype":0,"updatetime":"20160513114730","coverimages":[]},{"dbid":0,"id":888472,"title":"共享技术资源 日产收购三菱汽车34%股份","mediatype":0,"type":"新闻中心","time":"2016-05-13","intacttime":"2016/5/13 10:48:33","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g9/M0F/7E/DF/400x300_0_autohomecar__wKgH31c1QBWAE0zdAAD8vFDqeuU125.jpg","replycount":513,"pagecount":1,"jumppage":1,"lasttime":"20160513104833888472","newstype":0,"updatetime":"20160513104709","coverimages":[]},{"dbid":0,"id":888470,"title":"售8.88-9.68万元 哈弗H2舒适版车型上市","mediatype":0,"type":"新闻中心","time":"2016-05-13","intacttime":"2016/5/13 10:35:34","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g23/M02/5D/CF/400x300_0_autohomecar__wKgFXFc1PA6AS0VOAAE784n3Qxw700.jpg","replycount":865,"pagecount":1,"jumppage":1,"lasttime":"20160513103534888470","newstype":0,"updatetime":"20160513103505","coverimages":[]},{"dbid":0,"id":888469,"title":"富士重工将于明年4月更名\u201c斯巴鲁\u201d","mediatype":0,"type":"新闻中心","time":"2016-05-13","intacttime":"2016/5/13 9:34:59","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g9/M06/7E/38/400x300_0_autohomecar__wKgH0Fc1LOCAVImWAAA_pTiSi10641.jpg","replycount":700,"pagecount":1,"jumppage":1,"lasttime":"20160513093459888469","newstype":0,"updatetime":"20160513092639","coverimages":[]},{"dbid":0,"id":888467,"title":"或为XC40雏形 曝沃尔沃新概念车预告图","mediatype":0,"type":"新闻中心","time":"2016-05-13","intacttime":"2016/5/13 9:20:46","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g13/M0E/7B/F5/400x300_0_autohomecar__wKgH41c1IOKAc1SRAADLY3eA-Jg494.jpg","replycount":445,"pagecount":1,"jumppage":1,"lasttime":"20160513092046888467","newstype":0,"updatetime":"20160513091902","coverimages":[]},{"dbid":0,"id":888466,"title":"或2016年底亮相 雪佛兰全新Equinox谍照","mediatype":0,"type":"新闻中心","time":"2016-05-13","intacttime":"2016/5/13 7:54:25","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g11/M01/7B/21/400x300_0_autohomecar__wKgH4Vc1FzCARq7UAAFMw1J2e7I446.jpg","replycount":109,"pagecount":1,"jumppage":1,"lasttime":"20160513075425888466","newstype":0,"updatetime":"20160513075219","coverimages":[]},{"dbid":0,"id":888461,"title":"或配1.6T高功率发动机 现代i30 N新消息","mediatype":0,"type":"新闻中心","time":"2016-05-13","intacttime":"2016/5/13 6:05:00","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g8/M14/7D/C3/400x300_0_autohomecar__wKgH3lc0VwCABIaZAAGfD0gezN4761.jpg","replycount":246,"pagecount":1,"jumppage":1,"lasttime":"20160513060500888461","newstype":0,"updatetime":"20160512181340","coverimages":[]},{"dbid":0,"id":888458,"title":"或2017年初亮相 曝新款福特翼搏假想图","mediatype":0,"type":"新闻中心","time":"2016-05-13","intacttime":"2016/5/13 6:04:00","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g16/M12/7A/82/400x300_0_autohomecar__wKjBx1c0Tb2ADt3lAAGILbptsXE522.jpg","replycount":346,"pagecount":1,"jumppage":1,"lasttime":"20160513060400888458","newstype":0,"updatetime":"20160512173516","coverimages":[]},{"dbid":0,"id":888459,"title":"斯巴鲁发布LEVORG STi量产版车型预告图","mediatype":0,"type":"新闻中心","time":"2016-05-13","intacttime":"2016/5/13 6:00:00","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g10/M09/7A/D2/400x300_0_autohomecar__wKgH4Fc0TeKAZoiNAACr0ZAtvbY583.jpg","replycount":231,"pagecount":1,"jumppage":1,"lasttime":"20160513060000888459","newstype":0,"updatetime":"20160512175103","coverimages":[]},{"dbid":0,"id":888450,"title":"变相加价很普遍 全新思域四地购车调查","mediatype":0,"type":"新闻中心","time":"2016-05-13","intacttime":"2016/5/13 0:00:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g15/M02/78/61/400x300_0_autohomecar__wKgH5Vc0Ug-AF3fbAAGU_G9lsOM674.jpg","replycount":4406,"pagecount":3,"jumppage":1,"lasttime":"20160513000000888450","newstype":0,"updatetime":"20160513170622","coverimages":[]},{"dbid":0,"id":888462,"title":"销量不佳是主因 丰田FJ 酷路泽8月停产","mediatype":0,"type":"新闻中心","time":"2016-05-12","intacttime":"2016/5/12 20:10:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g14/M14/7B/77/400x300_0_autohomecar__wKgH5Fc0WLmAMXC_AAHrRpjm8v8358.jpg","replycount":1125,"pagecount":1,"jumppage":1,"lasttime":"20160512201000888462","newstype":0,"updatetime":"20160513163635","coverimages":[]},{"dbid":0,"id":888455,"title":"增加电子手刹 新款雪铁龙C4L实车曝光","mediatype":0,"type":"新闻中心","time":"2016-05-12","intacttime":"2016/5/12 20:05:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g15/M02/7B/AE/400x300_0_autohomecar__wKgH1lc0P7KAd-dSAAFIRNLgU8w586.jpg","replycount":701,"pagecount":1,"jumppage":1,"lasttime":"20160512200500888455","newstype":0,"updatetime":"20160512164733","coverimages":[]},{"dbid":0,"id":888457,"title":"搭载1.5T/2.0T 汉腾SUV动力信息曝光","mediatype":0,"type":"新闻中心","time":"2016-05-12","intacttime":"2016/5/12 20:01:00","indexdetail":"","smallpic":"http://www3.autoimg.cn/newsdfs/g13/M05/7A/BD/400x300_0_autohomecar__wKjBylc0P9OATHpkAAE9BLumDEE964.jpg","replycount":441,"pagecount":1,"jumppage":1,"lasttime":"20160512200100888457","newstype":0,"updatetime":"20160512164559","coverimages":[]},{"dbid":0,"id":888454,"title":"1.5T+5MT 野马T70升级版5月29日发布","mediatype":0,"type":"新闻中心","time":"2016-05-12","intacttime":"2016/5/12 17:14:22","indexdetail":"","smallpic":"http://www2.autoimg.cn/newsdfs/g11/M11/7A/93/400x300_0_autohomecar__wKgH4Vc0RH-AYtGTAAFWiU6edNg918.jpg","replycount":1376,"pagecount":1,"jumppage":1,"lasttime":"20160512171422888454","newstype":0,"updatetime":"20160513180508","coverimages":[]}],"topnewsinfo":{}}
     * returncode : 0
     * message :
     */

    private int returncode;
    private String message;

    public ResultBean getResult() {
        return result;
    }

    public void setResult(ResultBean result) {
        this.result = result;
    }

    public int getReturncode() {
        return returncode;
    }

    public void setReturncode(int returncode) {
        this.returncode = returncode;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public static class ResultBean {
        private int rowcount;
        private boolean isloadmore;
        private List<?> focusimg;
        /**
         * dbid : 0
         * id : 888505
         * title : 两款车型 江铃福特途睿欧5月19日上市
         * mediatype : 0
         * type : 新闻中心
         * time : 2016-05-14
         * intacttime : 2016/5/14 13:46:46
         * indexdetail :
         * smallpic : http://www2.autoimg.cn/newsdfs/g12/M07/7E/77/400x300_0_autohomecar__wKgH4lc2u4yAN9EEAAHV4PAcK5s863.jpg
         * replycount : 72
         * pagecount : 1
         * jumppage : 1
         * lasttime : 20160514134646888505
         * newstype : 0
         * updatetime : 20160514134555
         * coverimages : []
         */

        private List<NewslistBean> newslist;

        public int getRowcount() {
            return rowcount;
        }

        public void setRowcount(int rowcount) {
            this.rowcount = rowcount;
        }

        public boolean isIsloadmore() {
            return isloadmore;
        }

        public void setIsloadmore(boolean isloadmore) {
            this.isloadmore = isloadmore;
        }

        public List<?> getFocusimg() {
            return focusimg;
        }

        public void setFocusimg(List<?> focusimg) {
            this.focusimg = focusimg;
        }

        public List<NewslistBean> getNewslist() {
            return newslist;
        }

        public void setNewslist(List<NewslistBean> newslist) {
            this.newslist = newslist;
        }

        public static class NewslistBean {
            private int dbid;
            private int id;
            private String title;
            private int mediatype;
            private String type;
            private String time;
            private String intacttime;
            private String indexdetail;
            private String smallpic;
            private int replycount;
            private int pagecount;
            private int jumppage;
            private String lasttime;
            private int newstype;
            private String updatetime;
            private List<?> coverimages;

            public int getDbid() {
                return dbid;
            }

            public void setDbid(int dbid) {
                this.dbid = dbid;
            }

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public int getMediatype() {
                return mediatype;
            }

            public void setMediatype(int mediatype) {
                this.mediatype = mediatype;
            }

            public String getType() {
                return type;
            }

            public void setType(String type) {
                this.type = type;
            }

            public String getTime() {
                return time;
            }

            public void setTime(String time) {
                this.time = time;
            }

            public String getIntacttime() {
                return intacttime;
            }

            public void setIntacttime(String intacttime) {
                this.intacttime = intacttime;
            }

            public String getIndexdetail() {
                return indexdetail;
            }

            public void setIndexdetail(String indexdetail) {
                this.indexdetail = indexdetail;
            }

            public String getSmallpic() {
                return smallpic;
            }

            public void setSmallpic(String smallpic) {
                this.smallpic = smallpic;
            }

            public int getReplycount() {
                return replycount;
            }

            public void setReplycount(int replycount) {
                this.replycount = replycount;
            }

            public int getPagecount() {
                return pagecount;
            }

            public void setPagecount(int pagecount) {
                this.pagecount = pagecount;
            }

            public int getJumppage() {
                return jumppage;
            }

            public void setJumppage(int jumppage) {
                this.jumppage = jumppage;
            }

            public String getLasttime() {
                return lasttime;
            }

            public void setLasttime(String lasttime) {
                this.lasttime = lasttime;
            }

            public int getNewstype() {
                return newstype;
            }

            public void setNewstype(int newstype) {
                this.newstype = newstype;
            }

            public String getUpdatetime() {
                return updatetime;
            }

            public void setUpdatetime(String updatetime) {
                this.updatetime = updatetime;
            }

            public List<?> getCoverimages() {
                return coverimages;
            }

            public void setCoverimages(List<?> coverimages) {
                this.coverimages = coverimages;
            }
        }
    }
}
