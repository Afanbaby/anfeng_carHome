package com.lanou3g.an.carhome.articleNestingFragment.video;

import java.io.Serializable;
import java.util.List;
import java.util.SimpleTimeZone;

/**
 * Created by anfeng on 16/5/12.
 */
public class VideoBean {

    /**
     * isloadmore : true
     * rowcount : 67022
     * pagecount : 3192
     * pageindex : 0
     * list : [{"id":80488,"title":"《汽车洋葱圈》 概念车如何改变生活？","type":"花边","time":"2016-05-12","indexdetail":"汽车洋葱圈原创视频","smallimg":"http://www3.autoimg.cn/newsdfs/g19/M0F/5C/77/120x90_0_autohomecar__wKgFWFc0SwqAVtmVAAC-o4VSfxI203.jpg","replycount":4,"playcount":745,"nickname":"陆维","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80488.html","updatetime":"20160512172117","lastid":"201605121721172016051217213380488"},{"id":80448,"title":"疼得起不来 看红衣女子过马路惨被撞翻","type":"花边","time":"2016-05-12","indexdetail":"视频展示了女子通过斑马线时被高速驶来的汽车撞倒的惨烈画面","smallimg":"http://www2.autoimg.cn/newsdfs/g18/M03/79/21/120x90_0_autohomecar__wKjBxVcz5OCAFWjGAAD4cb0QSmE111.jpg","replycount":23,"playcount":10206,"nickname":"艾琦","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80448.html","updatetime":"20160512100529","lastid":"201605121005302016051216433380448"},{"id":80466,"title":"满场黑烟！暴改肌肉车疯狂烧胎漂移","type":"花边","time":"2016-05-12","indexdetail":"暴改肌肉车疯狂烧胎漂移","smallimg":"http://www2.autoimg.cn/newsdfs/g13/M12/7A/6E/120x90_0_autohomecar__wKjBylc0Dq2AVkwDAAFjTAdmDKQ032.jpg","replycount":53,"playcount":20012,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80466.html","updatetime":"20160512130344","lastid":"201605121303452016051216433380466"},{"id":80447,"title":"这个厉害了 高手开丰田AE86演示跟趾","type":"花边","time":"2016-05-12","indexdetail":"高手开丰田AE86演示跟趾","smallimg":"http://www2.autoimg.cn/newsdfs/g5/M14/7A/72/120x90_0_autohomecar__wKgH21cz5NyAKf7_AAGHmRwngMs844.jpg","replycount":148,"playcount":68848,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80447.html","updatetime":"20160512100517","lastid":"201605121005182016051216433380447"},{"id":80458,"title":"确实很牛掰 俄罗斯NIVA SUV暴强过河","type":"花边","time":"2016-05-12","indexdetail":"俄罗斯NIVA SUV暴强过河","smallimg":"http://www2.autoimg.cn/newsdfs/g6/M15/79/62/120x90_0_autohomecar__wKgHzVcz56CAFfOcAAFcbr8UZyk327.jpg","replycount":5,"playcount":8912,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80458.html","updatetime":"20160512101705","lastid":"201605121017062016051216433380458"},{"id":80420,"title":"《力所应当》第4集 遭遇熊抱突袭怎么办","type":"原创","time":"2016-05-11","indexdetail":"《力所应当》是由汽车之家和来自美国FORCE NECESSARY 战术格斗教官刘上共同打造的车用防身术情景剧，第四集《请君入瓮》主要为大家讲解被人从背后熊抱如何化解。","smallimg":"http://www2.autoimg.cn/newsdfs/g17/M09/74/4C/120x90_0_autohomecar__wKjBxlczVWCAZxtpAAEP1tkNdzg622.jpg","replycount":209,"playcount":78334,"nickname":"张文君","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_8_80420.html","updatetime":"20160511235309","lastid":"201605111924492016051216433380420"},{"id":80455,"title":"强行漂移失败 小车高速过弯翻到隔离带","type":"花边","time":"2016-05-12","indexdetail":"视频展示了小车高速过弯发生侧滑翻车的场面","smallimg":"http://www3.autoimg.cn/newsdfs/g20/M0D/5B/90/120x90_0_autohomecar__wKjBw1cz5oCAY7dHAAEE4Iwe3i0533.jpg","replycount":38,"playcount":6478,"nickname":"艾琦","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80455.html","updatetime":"20160512101218","lastid":"201605121012182016051216433380455"},{"id":80467,"title":"有一颗越野的心 小车压上石头动弹不得","type":"花边","time":"2016-05-12","indexdetail":"视频展示了小轿车开下草地绕路时骑到石头上动弹不得的场面","smallimg":"http://www3.autoimg.cn/newsdfs/g17/M00/74/8E/120x90_0_autohomecar__wKjBxlcz6uiAJeFRAAFKcKgxDSg469.jpg","replycount":17,"playcount":11132,"nickname":"艾琦","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80467.html","updatetime":"20160512103105","lastid":"201605121031062016051216433280467"},{"id":80444,"title":"涨姿势 高手全方面演示如何赛道攻弯","type":"花边","time":"2016-05-12","indexdetail":"高手全方面演示如何赛道攻弯","smallimg":"http://www2.autoimg.cn/newsdfs/g12/M03/7B/76/120x90_0_autohomecar__wKjBy1c0QJuAXSJVAADrQkNl2eM085.jpg","replycount":8,"playcount":3377,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80444.html","updatetime":"20160512163650","lastid":"201605121636502016051216433280444"},{"id":80471,"title":"够红才激情 近距离详拍2016款奥迪SQ5","type":"花边","time":"2016-05-12","indexdetail":"视频展示了2016款奥迪SQ5 TDI Plus车展近距离实拍","smallimg":"http://www3.autoimg.cn/newsdfs/g12/M03/78/DF/120x90_0_autohomecar__wKgH01c0QLCAbGEzAAGOESNv50U640.jpg","replycount":5,"playcount":4640,"nickname":"艾琦","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80471.html","updatetime":"20160512163707","lastid":"201605121637072016051216433280471"},{"id":80468,"title":"有实力 玛莎拉蒂Levante爬大坡展示","type":"花边","time":"2016-05-12","indexdetail":"玛莎拉蒂Levante爬大坡展示","smallimg":"http://www2.autoimg.cn/newsdfs/g14/M0C/7B/59/120x90_0_autohomecar__wKgH5Fc0QfeAFfz7AAF0u8IBOao677.jpg","replycount":42,"playcount":28287,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80468.html","updatetime":"20160512164250","lastid":"201605121642502016051216433280468"},{"id":80463,"title":"野蛮的驾驶风格 战斗民族最新车祸合集","type":"事件","time":"2016-05-12","indexdetail":"视频展示了一系列发生在俄罗斯的惨烈的车祸事故。虽然造成事故的因素有很多种，但其中最常见的因素还是肇事车辆的车速过快。鲁莽驾驶、不遵守交通法规、对路况的观察不全面等等一系列的不规范行为也是酿成惨祸的原因。总之，一次次的提醒都是希望广大车友和行人一定要注意交通安全，平安出行！","smallimg":"http://www3.autoimg.cn/newsdfs/g13/M12/7A/7C/120x90_0_autohomecar__wKgH1Fc0IASARga3AADW-zQoUSE861.jpg","replycount":44,"playcount":41963,"nickname":"陆维","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_7_80463.html","updatetime":"20160512130412","lastid":"201605121256222016051216433280463"},{"id":80470,"title":"动力强大 奥迪A5 2.0 TDI加速230km/h","type":"花边","time":"2016-05-12","indexdetail":"视频展示了2016款奥迪A5 S-Line 2.0 TDI动力强劲加速至230km/h实录","smallimg":"http://www3.autoimg.cn/newsdfs/g4/M0A/7A/3B/120x90_0_autohomecar__wKjB01c0QOSAKVrRAAFQh5b-kS0035.jpg","replycount":13,"playcount":7103,"nickname":"艾琦","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80470.html","updatetime":"20160512163758","lastid":"201605121637582016051216433280470"},{"id":80459,"title":"千万别超速 警察高速路扣押土豪的超跑","type":"花边","time":"2016-05-12","indexdetail":"警察高速路扣押土豪的超跑","smallimg":"http://www3.autoimg.cn/newsdfs/g16/M04/7A/15/120x90_0_autohomecar__wKgH5lcz5-uAIDc6AAEfXwHS4PE843.jpg","replycount":15,"playcount":7036,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80459.html","updatetime":"20160512101820","lastid":"201605121018212016051216433280459"},{"id":80464,"title":"美女演示 如何正确使用汽车的倒车辅助","type":"花边","time":"2016-05-12","indexdetail":"如何正确使用汽车的倒车辅助","smallimg":"http://www2.autoimg.cn/newsdfs/g12/M0F/78/E1/120x90_0_autohomecar__wKgH01c0QMKAAMr2AAF7Grm7Hpk819.jpg","replycount":10,"playcount":4123,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80464.html","updatetime":"20160512163726","lastid":"201605121637262016051216433280464"},{"id":80449,"title":"优雅大块头 详拍奔驰GLS 550 4MATIC","type":"花边","time":"2016-05-12","indexdetail":"动力方面，奔驰GLS有多款动力可选，其中GLS 450搭载3.0T V6双涡轮增压发动机，最大输出功率367马力，峰值扭矩500N·m；GLS 550搭载4.7T V8双涡轮增压发动机，最大输出功率为454马力，峰值扭矩为699N·m；GLS 350d则搭载了一台3.0T V6柴油发动机，最大输出功率258马力，峰值扭矩620N·m。不过目前国内将上市版本会采用哪种动力还未确定。在传动部分，新车将使用9速自动变速箱，并标配4MATIC四驱系统。而梅赛德斯-AMG GLS 63则配备了SPEEDSHIFT PLUS 7G-TRONIC双离合变速箱。","smallimg":"http://www2.autoimg.cn/newsdfs/g7/M07/79/8F/120x90_0_autohomecar__wKgHzlcz5UaAS7XxAAFiM1gw6bA646.jpg","replycount":182,"playcount":69516,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80449.html","updatetime":"20160512164118","lastid":"201605121255582016051216433280449"},{"id":80476,"title":"年轻时尚运动风 2016款骐达CVT智尊版","type":"到店实拍","time":"2016-05-12","indexdetail":"到店实拍 骐达 2016款 1.6L CVT智尊版","smallimg":"http://www3.autoimg.cn/newsdfs/g16/M0B/7A/39/120x90_0_autohomecar__wKgH5lcz_Z2AQT7jAAFMDK10680208.jpg","replycount":71,"playcount":38677,"nickname":"王腾（产品库）","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_9_80476.html","updatetime":"20160512115807","lastid":"201605121158082016051215210980476"},{"id":80481,"title":"《萝卜实验室》 磁性手机支架介绍/使用","type":"花边","time":"2016-05-12","indexdetail":"萝卜报告原创视频","smallimg":"http://www3.autoimg.cn/newsdfs/g9/M14/74/35/120x90_0_autohomecar__wKjBzlc0F--ATFz_AAFACgDGVL0151.jpg","replycount":57,"playcount":11922,"nickname":"陆维","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80481.html","updatetime":"20160512134312","lastid":"201605121343132016051213432680481"},{"id":80422,"title":"Ghibli Diesel 3.0T 秀诱人排气声浪","type":"花边","time":"2016-05-12","indexdetail":"视频展示了玛莎拉蒂Ghibli Diesel 3.0T V6的排气声浪","smallimg":"http://www3.autoimg.cn/newsdfs/g18/M01/79/12/120x90_0_autohomecar__wKjBxVcz2XeABp70AAGZvCkD2pY610.jpg","replycount":8,"playcount":4123,"nickname":"陆维","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80422.html","updatetime":"20160512091648","lastid":"201605120916482016051213115180422"},{"id":80427,"title":"真想骂街 摄像车躲避左转车冲上隔离带","type":"花边","time":"2016-05-12","indexdetail":"摄像车直行，为了躲避左转的绿色小车冲上隔离带，左转车居然直接开走了。","smallimg":"http://www3.autoimg.cn/newsdfs/g10/M12/79/F8/120x90_0_autohomecar__wKjBzVcz326AM4ckAAEtCV2tlLA065.jpg","replycount":23,"playcount":6522,"nickname":"艾琦","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80427.html","updatetime":"20160512094810","lastid":"201605120948112016051213114780427"}]
     */

    private ResultBean result;
    /**
     * result : {"isloadmore":true,"rowcount":67022,"pagecount":3192,"pageindex":0,"list":[{"id":80488,"title":"《汽车洋葱圈》 概念车如何改变生活？","type":"花边","time":"2016-05-12","indexdetail":"汽车洋葱圈原创视频","smallimg":"http://www3.autoimg.cn/newsdfs/g19/M0F/5C/77/120x90_0_autohomecar__wKgFWFc0SwqAVtmVAAC-o4VSfxI203.jpg","replycount":4,"playcount":745,"nickname":"陆维","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80488.html","updatetime":"20160512172117","lastid":"201605121721172016051217213380488"},{"id":80448,"title":"疼得起不来 看红衣女子过马路惨被撞翻","type":"花边","time":"2016-05-12","indexdetail":"视频展示了女子通过斑马线时被高速驶来的汽车撞倒的惨烈画面","smallimg":"http://www2.autoimg.cn/newsdfs/g18/M03/79/21/120x90_0_autohomecar__wKjBxVcz5OCAFWjGAAD4cb0QSmE111.jpg","replycount":23,"playcount":10206,"nickname":"艾琦","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80448.html","updatetime":"20160512100529","lastid":"201605121005302016051216433380448"},{"id":80466,"title":"满场黑烟！暴改肌肉车疯狂烧胎漂移","type":"花边","time":"2016-05-12","indexdetail":"暴改肌肉车疯狂烧胎漂移","smallimg":"http://www2.autoimg.cn/newsdfs/g13/M12/7A/6E/120x90_0_autohomecar__wKjBylc0Dq2AVkwDAAFjTAdmDKQ032.jpg","replycount":53,"playcount":20012,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80466.html","updatetime":"20160512130344","lastid":"201605121303452016051216433380466"},{"id":80447,"title":"这个厉害了 高手开丰田AE86演示跟趾","type":"花边","time":"2016-05-12","indexdetail":"高手开丰田AE86演示跟趾","smallimg":"http://www2.autoimg.cn/newsdfs/g5/M14/7A/72/120x90_0_autohomecar__wKgH21cz5NyAKf7_AAGHmRwngMs844.jpg","replycount":148,"playcount":68848,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80447.html","updatetime":"20160512100517","lastid":"201605121005182016051216433380447"},{"id":80458,"title":"确实很牛掰 俄罗斯NIVA SUV暴强过河","type":"花边","time":"2016-05-12","indexdetail":"俄罗斯NIVA SUV暴强过河","smallimg":"http://www2.autoimg.cn/newsdfs/g6/M15/79/62/120x90_0_autohomecar__wKgHzVcz56CAFfOcAAFcbr8UZyk327.jpg","replycount":5,"playcount":8912,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80458.html","updatetime":"20160512101705","lastid":"201605121017062016051216433380458"},{"id":80420,"title":"《力所应当》第4集 遭遇熊抱突袭怎么办","type":"原创","time":"2016-05-11","indexdetail":"《力所应当》是由汽车之家和来自美国FORCE NECESSARY 战术格斗教官刘上共同打造的车用防身术情景剧，第四集《请君入瓮》主要为大家讲解被人从背后熊抱如何化解。","smallimg":"http://www2.autoimg.cn/newsdfs/g17/M09/74/4C/120x90_0_autohomecar__wKjBxlczVWCAZxtpAAEP1tkNdzg622.jpg","replycount":209,"playcount":78334,"nickname":"张文君","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_8_80420.html","updatetime":"20160511235309","lastid":"201605111924492016051216433380420"},{"id":80455,"title":"强行漂移失败 小车高速过弯翻到隔离带","type":"花边","time":"2016-05-12","indexdetail":"视频展示了小车高速过弯发生侧滑翻车的场面","smallimg":"http://www3.autoimg.cn/newsdfs/g20/M0D/5B/90/120x90_0_autohomecar__wKjBw1cz5oCAY7dHAAEE4Iwe3i0533.jpg","replycount":38,"playcount":6478,"nickname":"艾琦","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80455.html","updatetime":"20160512101218","lastid":"201605121012182016051216433380455"},{"id":80467,"title":"有一颗越野的心 小车压上石头动弹不得","type":"花边","time":"2016-05-12","indexdetail":"视频展示了小轿车开下草地绕路时骑到石头上动弹不得的场面","smallimg":"http://www3.autoimg.cn/newsdfs/g17/M00/74/8E/120x90_0_autohomecar__wKjBxlcz6uiAJeFRAAFKcKgxDSg469.jpg","replycount":17,"playcount":11132,"nickname":"艾琦","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80467.html","updatetime":"20160512103105","lastid":"201605121031062016051216433280467"},{"id":80444,"title":"涨姿势 高手全方面演示如何赛道攻弯","type":"花边","time":"2016-05-12","indexdetail":"高手全方面演示如何赛道攻弯","smallimg":"http://www2.autoimg.cn/newsdfs/g12/M03/7B/76/120x90_0_autohomecar__wKjBy1c0QJuAXSJVAADrQkNl2eM085.jpg","replycount":8,"playcount":3377,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80444.html","updatetime":"20160512163650","lastid":"201605121636502016051216433280444"},{"id":80471,"title":"够红才激情 近距离详拍2016款奥迪SQ5","type":"花边","time":"2016-05-12","indexdetail":"视频展示了2016款奥迪SQ5 TDI Plus车展近距离实拍","smallimg":"http://www3.autoimg.cn/newsdfs/g12/M03/78/DF/120x90_0_autohomecar__wKgH01c0QLCAbGEzAAGOESNv50U640.jpg","replycount":5,"playcount":4640,"nickname":"艾琦","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80471.html","updatetime":"20160512163707","lastid":"201605121637072016051216433280471"},{"id":80468,"title":"有实力 玛莎拉蒂Levante爬大坡展示","type":"花边","time":"2016-05-12","indexdetail":"玛莎拉蒂Levante爬大坡展示","smallimg":"http://www2.autoimg.cn/newsdfs/g14/M0C/7B/59/120x90_0_autohomecar__wKgH5Fc0QfeAFfz7AAF0u8IBOao677.jpg","replycount":42,"playcount":28287,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80468.html","updatetime":"20160512164250","lastid":"201605121642502016051216433280468"},{"id":80463,"title":"野蛮的驾驶风格 战斗民族最新车祸合集","type":"事件","time":"2016-05-12","indexdetail":"视频展示了一系列发生在俄罗斯的惨烈的车祸事故。虽然造成事故的因素有很多种，但其中最常见的因素还是肇事车辆的车速过快。鲁莽驾驶、不遵守交通法规、对路况的观察不全面等等一系列的不规范行为也是酿成惨祸的原因。总之，一次次的提醒都是希望广大车友和行人一定要注意交通安全，平安出行！","smallimg":"http://www3.autoimg.cn/newsdfs/g13/M12/7A/7C/120x90_0_autohomecar__wKgH1Fc0IASARga3AADW-zQoUSE861.jpg","replycount":44,"playcount":41963,"nickname":"陆维","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_7_80463.html","updatetime":"20160512130412","lastid":"201605121256222016051216433280463"},{"id":80470,"title":"动力强大 奥迪A5 2.0 TDI加速230km/h","type":"花边","time":"2016-05-12","indexdetail":"视频展示了2016款奥迪A5 S-Line 2.0 TDI动力强劲加速至230km/h实录","smallimg":"http://www3.autoimg.cn/newsdfs/g4/M0A/7A/3B/120x90_0_autohomecar__wKjB01c0QOSAKVrRAAFQh5b-kS0035.jpg","replycount":13,"playcount":7103,"nickname":"艾琦","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80470.html","updatetime":"20160512163758","lastid":"201605121637582016051216433280470"},{"id":80459,"title":"千万别超速 警察高速路扣押土豪的超跑","type":"花边","time":"2016-05-12","indexdetail":"警察高速路扣押土豪的超跑","smallimg":"http://www3.autoimg.cn/newsdfs/g16/M04/7A/15/120x90_0_autohomecar__wKgH5lcz5-uAIDc6AAEfXwHS4PE843.jpg","replycount":15,"playcount":7036,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80459.html","updatetime":"20160512101820","lastid":"201605121018212016051216433280459"},{"id":80464,"title":"美女演示 如何正确使用汽车的倒车辅助","type":"花边","time":"2016-05-12","indexdetail":"如何正确使用汽车的倒车辅助","smallimg":"http://www2.autoimg.cn/newsdfs/g12/M0F/78/E1/120x90_0_autohomecar__wKgH01c0QMKAAMr2AAF7Grm7Hpk819.jpg","replycount":10,"playcount":4123,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80464.html","updatetime":"20160512163726","lastid":"201605121637262016051216433280464"},{"id":80449,"title":"优雅大块头 详拍奔驰GLS 550 4MATIC","type":"花边","time":"2016-05-12","indexdetail":"动力方面，奔驰GLS有多款动力可选，其中GLS 450搭载3.0T V6双涡轮增压发动机，最大输出功率367马力，峰值扭矩500N·m；GLS 550搭载4.7T V8双涡轮增压发动机，最大输出功率为454马力，峰值扭矩为699N·m；GLS 350d则搭载了一台3.0T V6柴油发动机，最大输出功率258马力，峰值扭矩620N·m。不过目前国内将上市版本会采用哪种动力还未确定。在传动部分，新车将使用9速自动变速箱，并标配4MATIC四驱系统。而梅赛德斯-AMG GLS 63则配备了SPEEDSHIFT PLUS 7G-TRONIC双离合变速箱。","smallimg":"http://www2.autoimg.cn/newsdfs/g7/M07/79/8F/120x90_0_autohomecar__wKgHzlcz5UaAS7XxAAFiM1gw6bA646.jpg","replycount":182,"playcount":69516,"nickname":"郭泽松","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80449.html","updatetime":"20160512164118","lastid":"201605121255582016051216433280449"},{"id":80476,"title":"年轻时尚运动风 2016款骐达CVT智尊版","type":"到店实拍","time":"2016-05-12","indexdetail":"到店实拍 骐达 2016款 1.6L CVT智尊版","smallimg":"http://www3.autoimg.cn/newsdfs/g16/M0B/7A/39/120x90_0_autohomecar__wKgH5lcz_Z2AQT7jAAFMDK10680208.jpg","replycount":71,"playcount":38677,"nickname":"王腾（产品库）","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_9_80476.html","updatetime":"20160512115807","lastid":"201605121158082016051215210980476"},{"id":80481,"title":"《萝卜实验室》 磁性手机支架介绍/使用","type":"花边","time":"2016-05-12","indexdetail":"萝卜报告原创视频","smallimg":"http://www3.autoimg.cn/newsdfs/g9/M14/74/35/120x90_0_autohomecar__wKjBzlc0F--ATFz_AAFACgDGVL0151.jpg","replycount":57,"playcount":11922,"nickname":"陆维","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80481.html","updatetime":"20160512134312","lastid":"201605121343132016051213432680481"},{"id":80422,"title":"Ghibli Diesel 3.0T 秀诱人排气声浪","type":"花边","time":"2016-05-12","indexdetail":"视频展示了玛莎拉蒂Ghibli Diesel 3.0T V6的排气声浪","smallimg":"http://www3.autoimg.cn/newsdfs/g18/M01/79/12/120x90_0_autohomecar__wKjBxVcz2XeABp70AAGZvCkD2pY610.jpg","replycount":8,"playcount":4123,"nickname":"陆维","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80422.html","updatetime":"20160512091648","lastid":"201605120916482016051213115180422"},{"id":80427,"title":"真想骂街 摄像车躲避左转车冲上隔离带","type":"花边","time":"2016-05-12","indexdetail":"摄像车直行，为了躲避左转的绿色小车冲上隔离带，左转车居然直接开走了。","smallimg":"http://www3.autoimg.cn/newsdfs/g10/M12/79/F8/120x90_0_autohomecar__wKjBzVcz326AM4ckAAEtCV2tlLA065.jpg","replycount":23,"playcount":6522,"nickname":"艾琦","videoaddress":"http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8","shareaddress":"http://v.autohome.com.cn/v_4_80427.html","updatetime":"20160512094810","lastid":"201605120948112016051213114780427"}]}
     * returncode : 0
     * message :
     */

    private int returncode;
    private String message;

    public ResultBean getResult() {
        return result;
    }

    public void setResult(ResultBean result) {
        this.result = result;
    }

    public int getReturncode() {
        return returncode;
    }

    public void setReturncode(int returncode) {
        this.returncode = returncode;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public static class ResultBean {
        private boolean isloadmore;
        private int rowcount;
        private int pagecount;
        private int pageindex;
        /**
         * id : 80488
         * title : 《汽车洋葱圈》 概念车如何改变生活？
         * type : 花边
         * time : 2016-05-12
         * indexdetail : 汽车洋葱圈原创视频
         * smallimg : http://www3.autoimg.cn/newsdfs/g19/M0F/5C/77/120x90_0_autohomecar__wKgFWFc0SwqAVtmVAAC-o4VSfxI203.jpg
         * replycount : 4
         * playcount : 745
         * nickname : 陆维
         * videoaddress : http://v.youku.com/player/getM3U8/vid//type/mp4/v.m3u8
         * shareaddress : http://v.autohome.com.cn/v_4_80488.html
         * updatetime : 20160512172117
         * lastid : 201605121721172016051217213380488
         */

        private List<ListBean> list;

        public boolean isIsloadmore() {
            return isloadmore;
        }

        public void setIsloadmore(boolean isloadmore) {
            this.isloadmore = isloadmore;
        }

        public int getRowcount() {
            return rowcount;
        }

        public void setRowcount(int rowcount) {
            this.rowcount = rowcount;
        }

        public int getPagecount() {
            return pagecount;
        }

        public void setPagecount(int pagecount) {
            this.pagecount = pagecount;
        }

        public int getPageindex() {
            return pageindex;
        }

        public void setPageindex(int pageindex) {
            this.pageindex = pageindex;
        }

        public List<ListBean> getList() {
            return list;
        }

        public void setList(List<ListBean> list) {
            this.list = list;
        }

        public static class ListBean implements Serializable {
            private int id;
            private String title;
            private String type;
            private String time;
            private String indexdetail;
            private String smallimg;
            private int replycount;
            private int playcount;
            private String nickname;
            private String videoaddress;
            private String shareaddress;
            private String updatetime;
            private String lastid;

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getType() {
                return type;
            }

            public void setType(String type) {
                this.type = type;
            }

            public String getTime() {
                return time;
            }

            public void setTime(String time) {
                this.time = time;
            }

            public String getIndexdetail() {
                return indexdetail;
            }

            public void setIndexdetail(String indexdetail) {
                this.indexdetail = indexdetail;
            }

            public String getSmallimg() {
                return smallimg;
            }

            public void setSmallimg(String smallimg) {
                this.smallimg = smallimg;
            }

            public int getReplycount() {
                return replycount;
            }

            public void setReplycount(int replycount) {
                this.replycount = replycount;
            }

            public int getPlaycount() {
                return playcount;
            }

            public void setPlaycount(int playcount) {
                this.playcount = playcount;
            }

            public String getNickname() {
                return nickname;
            }

            public void setNickname(String nickname) {
                this.nickname = nickname;
            }

            public String getVideoaddress() {
                return videoaddress;
            }

            public void setVideoaddress(String videoaddress) {
                this.videoaddress = videoaddress;
            }

            public String getShareaddress() {
                return shareaddress;
            }

            public void setShareaddress(String shareaddress) {
                this.shareaddress = shareaddress;
            }

            public String getUpdatetime() {
                return updatetime;
            }

            public void setUpdatetime(String updatetime) {
                this.updatetime = updatetime;
            }

            public String getLastid() {
                return lastid;
            }

            public void setLastid(String lastid) {
                this.lastid = lastid;
            }
        }
    }
}
