package com.lanou3g.an.carhome.my;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.lanou3g.an.carhome.R;
import com.lanou3g.an.carhome.beas.BaseFragment;
import com.lanou3g.an.carhome.main.MainActivity;
import com.lanou3g.an.carhome.utils.MyDrawable;

/**
 * Created by anfeng on 16/5/30.
 */
public class LoginAfterFragment extends BaseFragment implements View.OnClickListener {

    private ImageView linkManIv;
    private TextView returnIv;
    private MainActivity mainActivity;

    @Override
    public int setLayout() {
        return R.layout.activity_login_after;
    }

    @Override
    protected void initView() {
        linkManIv = bindView(R.id.myself_photo);
        returnIv = bindView(R.id.activity_login_return_login);
        returnIv.setOnClickListener(this);
    }

    @Override
    protected void initData() {
        Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.mipmap.my_love);
        linkManIv.setImageDrawable(new MyDrawable(bitmap));
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.activity_login_return_login:
                Intent intent = new Intent(context, MainActivity.class);
                startActivity(intent);
                break;
        }
    }
}
