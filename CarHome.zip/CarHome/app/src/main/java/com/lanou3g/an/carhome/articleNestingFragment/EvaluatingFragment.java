package com.lanou3g.an.carhome.articleNestingFragment;

import com.lanou3g.an.carhome.R;
import com.lanou3g.an.carhome.beas.BaseFragment;

/**
 * Created by anfeng on 16/5/9.
 *  推荐中的评测
 */
public class EvaluatingFragment extends BaseFragment {
    @Override
    public int setLayout() {
        return R.layout.fragment_evaluating;
    }

    @Override
    protected void initView() {

    }

    @Override
    protected void initData() {

    }
}
