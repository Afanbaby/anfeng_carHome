package com.lanou3g.an.carhome.forum.hot;

import java.util.List;

/**
 * Created by anfeng on 16/5/20.
 */
public class HotBean {

    /**
     * returncode : 0
     * message :
     * result : {"pagecount":4,"rowcount":28183,"pageindex":1,"list":[{"topicid":52622342,"title":"北五环外环520重大交通事故！更新，途安车主只腿部轻伤","lastreplydate":"2016-05-20 19:01:58","postusername":"玻璃一般的透明","replycounts":143,"ispictopic":1,"bbsid":100002,"bbsname":"北京论坛","postdate":"2016-05-20 09:01:53"},{"topicid":52618419,"title":"H7提车作业 + H7 VS 博越 求精！","lastreplydate":"2016-05-20 19:06:42","postusername":"小宇宝宝320","replycounts":316,"ispictopic":1,"bbsid":3074,"bbsname":"哈弗H7论坛","postdate":"2016-05-19 23:56:45"},{"topicid":52629357,"title":"CX-4的价格公布了，说两句，大家看在不在理","lastreplydate":"2016-05-20 19:08:43","postusername":"阿姨洗汰露","replycounts":157,"ispictopic":1,"bbsid":3968,"bbsname":"马自达CX-4论坛","postdate":"2016-05-20 12:44:16"},{"topicid":52614787,"title":"小心翼翼还是出车祸了！！！！！！！！","lastreplydate":"2016-05-20 19:10:28","postusername":"h401033767","replycounts":122,"ispictopic":1,"bbsid":3405,"bbsname":"艾瑞泽5论坛","postdate":"2016-05-19 21:54:14"},{"topicid":52614106,"title":"今天试驾了博越，感觉行驶起来整车缺少安全感！","lastreplydate":"2016-05-20 19:09:48","postusername":"ke0834","replycounts":123,"ispictopic":0,"bbsid":3788,"bbsname":"博越论坛","postdate":"2016-05-19 21:33:56"},{"topicid":52613960,"title":"突然觉得吉利咋那么抠门呢？吐槽下方向盘","lastreplydate":"2016-05-20 18:07:02","postusername":"mwqc2010","replycounts":78,"ispictopic":1,"bbsid":3465,"bbsname":"帝豪GS论坛","postdate":"2016-05-19 21:29:31"},{"topicid":52620799,"title":"Gs入手咋样，宅女带你们秀秀，","lastreplydate":"2016-05-20 19:08:20","postusername":"玩我想突破天元","replycounts":108,"ispictopic":1,"bbsid":3465,"bbsname":"帝豪GS论坛","postdate":"2016-05-20 07:18:53"},{"topicid":52615519,"title":"听说上海人提车不看日子，买房也不看风水，是真的吗？","lastreplydate":"2016-05-20 18:58:37","postusername":"constant1","replycounts":480,"ispictopic":1,"bbsid":100024,"bbsname":"上海论坛","postdate":"2016-05-19 22:14:34"},{"topicid":52610897,"title":"软妹子与肌肉男的一天，一路好心情！","lastreplydate":"2016-05-20 18:45:57","postusername":"好想有个很牛很牛的牛","replycounts":21,"ispictopic":1,"bbsid":521,"bbsname":"大切诺基论坛","postdate":"2016-05-19 19:43:38"},{"topicid":52613197,"title":"老婆大人神一样的车技。。。","lastreplydate":"2016-05-20 19:11:16","postusername":"快放开那个姑娘","replycounts":169,"ispictopic":1,"bbsid":100024,"bbsname":"上海论坛","postdate":"2016-05-19 21:05:13"},{"topicid":52614903,"title":"rx5价格出来啦，今天刚得到的。","lastreplydate":"2016-05-20 19:04:11","postusername":"不再飞天的超人","replycounts":204,"ispictopic":0,"bbsid":4080,"bbsname":"荣威RX5论坛","postdate":"2016-05-19 21:57:56"},{"topicid":52621880,"title":"什么事以后再说吧！","lastreplydate":"2016-05-20 18:32:11","postusername":"cailiangchu","replycounts":171,"ispictopic":0,"bbsid":3788,"bbsname":"博越论坛","postdate":"2016-05-20 08:40:42"},{"topicid":52614604,"title":"【智尊博越】婚车当道 原配+\u201c小三\u201d喜过门","lastreplydate":"2016-05-20 18:55:38","postusername":"唯一920","replycounts":74,"ispictopic":1,"bbsid":3788,"bbsname":"博越论坛","postdate":"2016-05-19 21:49:18"},{"topicid":52632966,"title":"【河南乔森】33000公里--七保归来","lastreplydate":"2016-05-20 18:00:47","postusername":"彭彭儿shell","replycounts":53,"ispictopic":1,"bbsid":2334,"bbsname":"众泰T600论坛","postdate":"2016-05-20 14:42:47"},{"topicid":52626919,"title":"又撞啦！！ 自己受损严重，对方整个侧翻！！","lastreplydate":"2016-05-20 18:30:46","postusername":"豪油","replycounts":86,"ispictopic":1,"bbsid":3788,"bbsname":"博越论坛","postdate":"2016-05-20 11:23:33"},{"topicid":52610327,"title":"用了欧风700FTX 5W30润滑油一年，不但省油，动力也变强了","lastreplydate":"2016-05-20 16:36:23","postusername":"长安小男人","replycounts":5,"ispictopic":1,"bbsid":200028,"bbsname":"维修保养论坛","postdate":"2016-05-19 19:22:14"},{"topicid":52631610,"title":"纯属遐想，欢乐颂第二季给五美配上这些车会怎样","lastreplydate":"2016-05-20 19:03:12","postusername":"冬阳汽车","replycounts":7,"ispictopic":1,"bbsid":2246,"bbsname":"起亚K5论坛","postdate":"2016-05-20 13:59:17"},{"topicid":52627740,"title":"【大长腿、小高跟儿、炫腹肌】带着模特儿去探险\u2014\u2014KTM工厂摄影","lastreplydate":"2016-05-20 19:04:21","postusername":"Beckham1975","replycounts":90,"ispictopic":1,"bbsid":200063,"bbsname":"摩托车论坛","postdate":"2016-05-20 11:48:32"},{"topicid":52614387,"title":"你们要车还是要人","lastreplydate":"2016-05-20 19:08:38","postusername":"泡泡走起","replycounts":158,"ispictopic":1,"bbsid":3465,"bbsname":"帝豪GS论坛","postdate":"2016-05-19 21:42:39"},{"topicid":52612567,"title":"5.20博越我爱你，智尊黑提车作业，媳妇当车模哟....","lastreplydate":"2016-05-20 19:10:13","postusername":"夏天的鱼儿啊","replycounts":97,"ispictopic":1,"bbsid":3788,"bbsname":"博越论坛","postdate":"2016-05-19 20:45:14"},{"topicid":52616543,"title":"一个富二代对新E价格的看法","lastreplydate":"2016-05-20 19:09:07","postusername":"cygnux","replycounts":99,"ispictopic":1,"bbsid":197,"bbsname":"奔驰E级论坛","postdate":"2016-05-19 22:43:45"},{"topicid":52616298,"title":"趁年轻继续任性，女汉子订帝豪 gs","lastreplydate":"2016-05-20 19:03:56","postusername":"朴哥队长","replycounts":84,"ispictopic":1,"bbsid":3465,"bbsname":"帝豪GS论坛","postdate":"2016-05-19 22:36:22"},{"topicid":52625265,"title":"今天早上同事身上发生了一件大快人心的好事","lastreplydate":"2016-05-20 19:10:44","postusername":"tjb0514","replycounts":161,"ispictopic":0,"bbsid":100024,"bbsname":"上海论坛","postdate":"2016-05-20 10:37:21"},{"topicid":52613530,"title":"新皇冠致命缺陷，新车跑偏无法维修，车友购车需擦亮双眼！","lastreplydate":"2016-05-20 18:53:52","postusername":"山陬水涯","replycounts":339,"ispictopic":1,"bbsid":882,"bbsname":"皇冠论坛","postdate":"2016-05-19 21:16:44"},{"topicid":52616725,"title":"同学说3系是最垃圾的车，我就呵呵了。。。","lastreplydate":"2016-05-20 19:09:01","postusername":"kuancc","replycounts":103,"ispictopic":0,"bbsid":66,"bbsname":"宝马3系论坛","postdate":"2016-05-19 22:50:30"},{"topicid":52613474,"title":"离职了，好苦逼","lastreplydate":"2016-05-20 19:02:53","postusername":"小亮亮2013","replycounts":150,"ispictopic":1,"bbsid":100024,"bbsname":"上海论坛","postdate":"2016-05-19 21:14:46"},{"topicid":52615531,"title":"今天探望一个生病同事，才知道医疗吞噬财富的速度","lastreplydate":"2016-05-20 19:10:36","postusername":"forstiron","replycounts":431,"ispictopic":0,"bbsid":100024,"bbsname":"上海论坛","postdate":"2016-05-19 22:14:51"},{"topicid":52612488,"title":"高速行驶中熄火。让更多的人看到，求吉利重视。","lastreplydate":"2016-05-20 19:06:55","postusername":"古月一胡","replycounts":360,"ispictopic":1,"bbsid":3556,"bbsname":"帝豪论坛","postdate":"2016-05-19 20:42:53"},{"topicid":52625121,"title":"【奶爸课堂】那些年关于首保的那点事","lastreplydate":"2016-05-20 19:00:49","postusername":"20082015","replycounts":65,"ispictopic":1,"bbsid":3429,"bbsname":"雪铁龙C3-XR论坛","postdate":"2016-05-20 10:33:22"},{"topicid":52616266,"title":"一见钟情爱上你\u2014\u2014三儿~~","lastreplydate":"2016-05-20 19:07:48","postusername":"神情况","replycounts":31,"ispictopic":1,"bbsid":3080,"bbsname":"瑞风S3论坛","postdate":"2016-05-19 22:35:18"},{"topicid":52616496,"title":"女生适合开思域吗？ 求解答~ 鲍照图奉上。","lastreplydate":"2016-05-20 18:41:08","postusername":"意说","replycounts":54,"ispictopic":1,"bbsid":9901135,"bbsname":"新思域论坛","postdate":"2016-05-19 22:42:25"},{"topicid":52616013,"title":"奥迪A4l跟大众cc哪款适合93萌妹","lastreplydate":"2016-05-20 19:09:00","postusername":"红河小酒","replycounts":167,"ispictopic":1,"bbsid":692,"bbsname":"奥迪A4L论坛","postdate":"2016-05-19 22:28:02"},{"topicid":52610657,"title":"单车一家三口开着哈弗游全国（持续更新）","lastreplydate":"2016-05-20 19:10:28","postusername":"kuancc","replycounts":99,"ispictopic":1,"bbsid":2027,"bbsname":"哈弗H5论坛","postdate":"2016-05-19 19:34:19"},{"topicid":52614263,"title":"全新爱丽舍自时提车向大家汇报了","lastreplydate":"2016-05-20 18:55:58","postusername":"汤峪温泉妙玉阁玉器","replycounts":55,"ispictopic":1,"bbsid":98,"bbsname":"爱丽舍论坛","postdate":"2016-05-19 21:39:07"},{"topicid":52612416,"title":"美式味道，XT5提车初体验","lastreplydate":"2016-05-20 18:47:18","postusername":"pinkafro","replycounts":49,"ispictopic":1,"bbsid":3989,"bbsname":"凯迪拉克XT5论坛","postdate":"2016-05-19 20:40:41"},{"topicid":52620751,"title":"招募预言帝 大家公部售价之前每楼层留言预言价格","lastreplydate":"2016-05-20 18:33:10","postusername":"胖胖的悟空","replycounts":220,"ispictopic":1,"bbsid":3968,"bbsname":"马自达CX-4论坛","postdate":"2016-05-20 07:12:53"},{"topicid":52614538,"title":"车身车内装饰，内有油耗\u2014\u2014旅行盒子『脖子生活第二弹』","lastreplydate":"2016-05-20 18:15:47","postusername":"神的愤怒1163","replycounts":127,"ispictopic":1,"bbsid":3788,"bbsname":"博越论坛","postdate":"2016-05-19 21:47:12"},{"topicid":52613669,"title":"十代思域降价了 有图有真相","lastreplydate":"2016-05-20 17:54:59","postusername":"曾小仙","replycounts":31,"ispictopic":1,"bbsid":135,"bbsname":"思域论坛","postdate":"2016-05-19 21:20:46"},{"topicid":52633319,"title":"有幸试驾还未上市的A6，不对，是瑞风A60，求射！","lastreplydate":"2016-05-20 19:01:26","postusername":"416390031","replycounts":32,"ispictopic":1,"bbsid":3363,"bbsname":"瑞风A60论坛","postdate":"2016-05-20 14:54:22"},{"topicid":52619611,"title":"重庆技术控提博越1.8T感想","lastreplydate":"2016-05-20 18:25:39","postusername":"穷车","replycounts":157,"ispictopic":1,"bbsid":3788,"bbsname":"博越论坛","postdate":"2016-05-20 01:31:28"},{"topicid":52627861,"title":"现在预售价和配置都出来了，大家怎么看？车神车盲都可以进来口水","lastreplydate":"2016-05-20 18:42:37","postusername":"lww666999","replycounts":138,"ispictopic":0,"bbsid":3968,"bbsname":"马自达CX-4论坛","postdate":"2016-05-20 11:51:54"},{"topicid":52619025,"title":"萌妹入cx4，你表白了吗，","lastreplydate":"2016-05-20 19:02:13","postusername":"夜雨枫痕","replycounts":212,"ispictopic":1,"bbsid":3968,"bbsname":"马自达CX-4论坛","postdate":"2016-05-20 00:29:09"},{"topicid":52627083,"title":"一手消息，大家可以散了","lastreplydate":"2016-05-20 19:10:25","postusername":"xyz7782","replycounts":183,"ispictopic":1,"bbsid":3968,"bbsname":"马自达CX-4论坛","postdate":"2016-05-20 11:28:25"},{"topicid":52618469,"title":"我的小S\u2014\u2014终于等到你","lastreplydate":"2016-05-20 18:51:37","postusername":"唯一920","replycounts":58,"ispictopic":1,"bbsid":3465,"bbsname":"帝豪GS论坛","postdate":"2016-05-19 23:59:14"},{"topicid":52620457,"title":"**给想在GS上装6AT的\u201c小白们\u201d上课！给对6DCT有担忧的壮胆！","lastreplydate":"2016-05-20 18:53:50","postusername":"唯一920","replycounts":300,"ispictopic":1,"bbsid":3465,"bbsname":"帝豪GS论坛","postdate":"2016-05-20 06:33:03"},{"topicid":52610086,"title":"提车累了一天，不想多说，直接上图，","lastreplydate":"2016-05-20 18:57:13","postusername":"矢泽nico","replycounts":56,"ispictopic":1,"bbsid":135,"bbsname":"思域论坛","postdate":"2016-05-19 19:13:41"},{"topicid":52628016,"title":"14.98骂声一片，14.18也骂声一片。。。","lastreplydate":"2016-05-20 18:56:22","postusername":"恨屎不是饭","replycounts":136,"ispictopic":0,"bbsid":3968,"bbsname":"马自达CX-4论坛","postdate":"2016-05-20 11:56:17"},{"topicid":52615020,"title":"恭喜吉利！贺喜吉利！好消息","lastreplydate":"2016-05-20 19:03:52","postusername":"天道酬勤股道至简","replycounts":37,"ispictopic":1,"bbsid":3465,"bbsname":"帝豪GS论坛","postdate":"2016-05-19 22:00:49"},{"topicid":52621001,"title":"掰断交警手指 running白完！","lastreplydate":"2016-05-20 19:05:37","postusername":"年糕_518","replycounts":126,"ispictopic":1,"bbsid":100024,"bbsname":"上海论坛","postdate":"2016-05-20 07:40:46"}]}
     */

    private int returncode;
    private String message;
    /**
     * pagecount : 4
     * rowcount : 28183
     * pageindex : 1
     * list : [{"topicid":52622342,"title":"北五环外环520重大交通事故！更新，途安车主只腿部轻伤","lastreplydate":"2016-05-20 19:01:58","postusername":"玻璃一般的透明","replycounts":143,"ispictopic":1,"bbsid":100002,"bbsname":"北京论坛","postdate":"2016-05-20 09:01:53"},{"topicid":52618419,"title":"H7提车作业 + H7 VS 博越 求精！","lastreplydate":"2016-05-20 19:06:42","postusername":"小宇宝宝320","replycounts":316,"ispictopic":1,"bbsid":3074,"bbsname":"哈弗H7论坛","postdate":"2016-05-19 23:56:45"},{"topicid":52629357,"title":"CX-4的价格公布了，说两句，大家看在不在理","lastreplydate":"2016-05-20 19:08:43","postusername":"阿姨洗汰露","replycounts":157,"ispictopic":1,"bbsid":3968,"bbsname":"马自达CX-4论坛","postdate":"2016-05-20 12:44:16"},{"topicid":52614787,"title":"小心翼翼还是出车祸了！！！！！！！！","lastreplydate":"2016-05-20 19:10:28","postusername":"h401033767","replycounts":122,"ispictopic":1,"bbsid":3405,"bbsname":"艾瑞泽5论坛","postdate":"2016-05-19 21:54:14"},{"topicid":52614106,"title":"今天试驾了博越，感觉行驶起来整车缺少安全感！","lastreplydate":"2016-05-20 19:09:48","postusername":"ke0834","replycounts":123,"ispictopic":0,"bbsid":3788,"bbsname":"博越论坛","postdate":"2016-05-19 21:33:56"},{"topicid":52613960,"title":"突然觉得吉利咋那么抠门呢？吐槽下方向盘","lastreplydate":"2016-05-20 18:07:02","postusername":"mwqc2010","replycounts":78,"ispictopic":1,"bbsid":3465,"bbsname":"帝豪GS论坛","postdate":"2016-05-19 21:29:31"},{"topicid":52620799,"title":"Gs入手咋样，宅女带你们秀秀，","lastreplydate":"2016-05-20 19:08:20","postusername":"玩我想突破天元","replycounts":108,"ispictopic":1,"bbsid":3465,"bbsname":"帝豪GS论坛","postdate":"2016-05-20 07:18:53"},{"topicid":52615519,"title":"听说上海人提车不看日子，买房也不看风水，是真的吗？","lastreplydate":"2016-05-20 18:58:37","postusername":"constant1","replycounts":480,"ispictopic":1,"bbsid":100024,"bbsname":"上海论坛","postdate":"2016-05-19 22:14:34"},{"topicid":52610897,"title":"软妹子与肌肉男的一天，一路好心情！","lastreplydate":"2016-05-20 18:45:57","postusername":"好想有个很牛很牛的牛","replycounts":21,"ispictopic":1,"bbsid":521,"bbsname":"大切诺基论坛","postdate":"2016-05-19 19:43:38"},{"topicid":52613197,"title":"老婆大人神一样的车技。。。","lastreplydate":"2016-05-20 19:11:16","postusername":"快放开那个姑娘","replycounts":169,"ispictopic":1,"bbsid":100024,"bbsname":"上海论坛","postdate":"2016-05-19 21:05:13"},{"topicid":52614903,"title":"rx5价格出来啦，今天刚得到的。","lastreplydate":"2016-05-20 19:04:11","postusername":"不再飞天的超人","replycounts":204,"ispictopic":0,"bbsid":4080,"bbsname":"荣威RX5论坛","postdate":"2016-05-19 21:57:56"},{"topicid":52621880,"title":"什么事以后再说吧！","lastreplydate":"2016-05-20 18:32:11","postusername":"cailiangchu","replycounts":171,"ispictopic":0,"bbsid":3788,"bbsname":"博越论坛","postdate":"2016-05-20 08:40:42"},{"topicid":52614604,"title":"【智尊博越】婚车当道 原配+\u201c小三\u201d喜过门","lastreplydate":"2016-05-20 18:55:38","postusername":"唯一920","replycounts":74,"ispictopic":1,"bbsid":3788,"bbsname":"博越论坛","postdate":"2016-05-19 21:49:18"},{"topicid":52632966,"title":"【河南乔森】33000公里--七保归来","lastreplydate":"2016-05-20 18:00:47","postusername":"彭彭儿shell","replycounts":53,"ispictopic":1,"bbsid":2334,"bbsname":"众泰T600论坛","postdate":"2016-05-20 14:42:47"},{"topicid":52626919,"title":"又撞啦！！ 自己受损严重，对方整个侧翻！！","lastreplydate":"2016-05-20 18:30:46","postusername":"豪油","replycounts":86,"ispictopic":1,"bbsid":3788,"bbsname":"博越论坛","postdate":"2016-05-20 11:23:33"},{"topicid":52610327,"title":"用了欧风700FTX 5W30润滑油一年，不但省油，动力也变强了","lastreplydate":"2016-05-20 16:36:23","postusername":"长安小男人","replycounts":5,"ispictopic":1,"bbsid":200028,"bbsname":"维修保养论坛","postdate":"2016-05-19 19:22:14"},{"topicid":52631610,"title":"纯属遐想，欢乐颂第二季给五美配上这些车会怎样","lastreplydate":"2016-05-20 19:03:12","postusername":"冬阳汽车","replycounts":7,"ispictopic":1,"bbsid":2246,"bbsname":"起亚K5论坛","postdate":"2016-05-20 13:59:17"},{"topicid":52627740,"title":"【大长腿、小高跟儿、炫腹肌】带着模特儿去探险\u2014\u2014KTM工厂摄影","lastreplydate":"2016-05-20 19:04:21","postusername":"Beckham1975","replycounts":90,"ispictopic":1,"bbsid":200063,"bbsname":"摩托车论坛","postdate":"2016-05-20 11:48:32"},{"topicid":52614387,"title":"你们要车还是要人","lastreplydate":"2016-05-20 19:08:38","postusername":"泡泡走起","replycounts":158,"ispictopic":1,"bbsid":3465,"bbsname":"帝豪GS论坛","postdate":"2016-05-19 21:42:39"},{"topicid":52612567,"title":"5.20博越我爱你，智尊黑提车作业，媳妇当车模哟....","lastreplydate":"2016-05-20 19:10:13","postusername":"夏天的鱼儿啊","replycounts":97,"ispictopic":1,"bbsid":3788,"bbsname":"博越论坛","postdate":"2016-05-19 20:45:14"},{"topicid":52616543,"title":"一个富二代对新E价格的看法","lastreplydate":"2016-05-20 19:09:07","postusername":"cygnux","replycounts":99,"ispictopic":1,"bbsid":197,"bbsname":"奔驰E级论坛","postdate":"2016-05-19 22:43:45"},{"topicid":52616298,"title":"趁年轻继续任性，女汉子订帝豪 gs","lastreplydate":"2016-05-20 19:03:56","postusername":"朴哥队长","replycounts":84,"ispictopic":1,"bbsid":3465,"bbsname":"帝豪GS论坛","postdate":"2016-05-19 22:36:22"},{"topicid":52625265,"title":"今天早上同事身上发生了一件大快人心的好事","lastreplydate":"2016-05-20 19:10:44","postusername":"tjb0514","replycounts":161,"ispictopic":0,"bbsid":100024,"bbsname":"上海论坛","postdate":"2016-05-20 10:37:21"},{"topicid":52613530,"title":"新皇冠致命缺陷，新车跑偏无法维修，车友购车需擦亮双眼！","lastreplydate":"2016-05-20 18:53:52","postusername":"山陬水涯","replycounts":339,"ispictopic":1,"bbsid":882,"bbsname":"皇冠论坛","postdate":"2016-05-19 21:16:44"},{"topicid":52616725,"title":"同学说3系是最垃圾的车，我就呵呵了。。。","lastreplydate":"2016-05-20 19:09:01","postusername":"kuancc","replycounts":103,"ispictopic":0,"bbsid":66,"bbsname":"宝马3系论坛","postdate":"2016-05-19 22:50:30"},{"topicid":52613474,"title":"离职了，好苦逼","lastreplydate":"2016-05-20 19:02:53","postusername":"小亮亮2013","replycounts":150,"ispictopic":1,"bbsid":100024,"bbsname":"上海论坛","postdate":"2016-05-19 21:14:46"},{"topicid":52615531,"title":"今天探望一个生病同事，才知道医疗吞噬财富的速度","lastreplydate":"2016-05-20 19:10:36","postusername":"forstiron","replycounts":431,"ispictopic":0,"bbsid":100024,"bbsname":"上海论坛","postdate":"2016-05-19 22:14:51"},{"topicid":52612488,"title":"高速行驶中熄火。让更多的人看到，求吉利重视。","lastreplydate":"2016-05-20 19:06:55","postusername":"古月一胡","replycounts":360,"ispictopic":1,"bbsid":3556,"bbsname":"帝豪论坛","postdate":"2016-05-19 20:42:53"},{"topicid":52625121,"title":"【奶爸课堂】那些年关于首保的那点事","lastreplydate":"2016-05-20 19:00:49","postusername":"20082015","replycounts":65,"ispictopic":1,"bbsid":3429,"bbsname":"雪铁龙C3-XR论坛","postdate":"2016-05-20 10:33:22"},{"topicid":52616266,"title":"一见钟情爱上你\u2014\u2014三儿~~","lastreplydate":"2016-05-20 19:07:48","postusername":"神情况","replycounts":31,"ispictopic":1,"bbsid":3080,"bbsname":"瑞风S3论坛","postdate":"2016-05-19 22:35:18"},{"topicid":52616496,"title":"女生适合开思域吗？ 求解答~ 鲍照图奉上。","lastreplydate":"2016-05-20 18:41:08","postusername":"意说","replycounts":54,"ispictopic":1,"bbsid":9901135,"bbsname":"新思域论坛","postdate":"2016-05-19 22:42:25"},{"topicid":52616013,"title":"奥迪A4l跟大众cc哪款适合93萌妹","lastreplydate":"2016-05-20 19:09:00","postusername":"红河小酒","replycounts":167,"ispictopic":1,"bbsid":692,"bbsname":"奥迪A4L论坛","postdate":"2016-05-19 22:28:02"},{"topicid":52610657,"title":"单车一家三口开着哈弗游全国（持续更新）","lastreplydate":"2016-05-20 19:10:28","postusername":"kuancc","replycounts":99,"ispictopic":1,"bbsid":2027,"bbsname":"哈弗H5论坛","postdate":"2016-05-19 19:34:19"},{"topicid":52614263,"title":"全新爱丽舍自时提车向大家汇报了","lastreplydate":"2016-05-20 18:55:58","postusername":"汤峪温泉妙玉阁玉器","replycounts":55,"ispictopic":1,"bbsid":98,"bbsname":"爱丽舍论坛","postdate":"2016-05-19 21:39:07"},{"topicid":52612416,"title":"美式味道，XT5提车初体验","lastreplydate":"2016-05-20 18:47:18","postusername":"pinkafro","replycounts":49,"ispictopic":1,"bbsid":3989,"bbsname":"凯迪拉克XT5论坛","postdate":"2016-05-19 20:40:41"},{"topicid":52620751,"title":"招募预言帝 大家公部售价之前每楼层留言预言价格","lastreplydate":"2016-05-20 18:33:10","postusername":"胖胖的悟空","replycounts":220,"ispictopic":1,"bbsid":3968,"bbsname":"马自达CX-4论坛","postdate":"2016-05-20 07:12:53"},{"topicid":52614538,"title":"车身车内装饰，内有油耗\u2014\u2014旅行盒子『脖子生活第二弹』","lastreplydate":"2016-05-20 18:15:47","postusername":"神的愤怒1163","replycounts":127,"ispictopic":1,"bbsid":3788,"bbsname":"博越论坛","postdate":"2016-05-19 21:47:12"},{"topicid":52613669,"title":"十代思域降价了 有图有真相","lastreplydate":"2016-05-20 17:54:59","postusername":"曾小仙","replycounts":31,"ispictopic":1,"bbsid":135,"bbsname":"思域论坛","postdate":"2016-05-19 21:20:46"},{"topicid":52633319,"title":"有幸试驾还未上市的A6，不对，是瑞风A60，求射！","lastreplydate":"2016-05-20 19:01:26","postusername":"416390031","replycounts":32,"ispictopic":1,"bbsid":3363,"bbsname":"瑞风A60论坛","postdate":"2016-05-20 14:54:22"},{"topicid":52619611,"title":"重庆技术控提博越1.8T感想","lastreplydate":"2016-05-20 18:25:39","postusername":"穷车","replycounts":157,"ispictopic":1,"bbsid":3788,"bbsname":"博越论坛","postdate":"2016-05-20 01:31:28"},{"topicid":52627861,"title":"现在预售价和配置都出来了，大家怎么看？车神车盲都可以进来口水","lastreplydate":"2016-05-20 18:42:37","postusername":"lww666999","replycounts":138,"ispictopic":0,"bbsid":3968,"bbsname":"马自达CX-4论坛","postdate":"2016-05-20 11:51:54"},{"topicid":52619025,"title":"萌妹入cx4，你表白了吗，","lastreplydate":"2016-05-20 19:02:13","postusername":"夜雨枫痕","replycounts":212,"ispictopic":1,"bbsid":3968,"bbsname":"马自达CX-4论坛","postdate":"2016-05-20 00:29:09"},{"topicid":52627083,"title":"一手消息，大家可以散了","lastreplydate":"2016-05-20 19:10:25","postusername":"xyz7782","replycounts":183,"ispictopic":1,"bbsid":3968,"bbsname":"马自达CX-4论坛","postdate":"2016-05-20 11:28:25"},{"topicid":52618469,"title":"我的小S\u2014\u2014终于等到你","lastreplydate":"2016-05-20 18:51:37","postusername":"唯一920","replycounts":58,"ispictopic":1,"bbsid":3465,"bbsname":"帝豪GS论坛","postdate":"2016-05-19 23:59:14"},{"topicid":52620457,"title":"**给想在GS上装6AT的\u201c小白们\u201d上课！给对6DCT有担忧的壮胆！","lastreplydate":"2016-05-20 18:53:50","postusername":"唯一920","replycounts":300,"ispictopic":1,"bbsid":3465,"bbsname":"帝豪GS论坛","postdate":"2016-05-20 06:33:03"},{"topicid":52610086,"title":"提车累了一天，不想多说，直接上图，","lastreplydate":"2016-05-20 18:57:13","postusername":"矢泽nico","replycounts":56,"ispictopic":1,"bbsid":135,"bbsname":"思域论坛","postdate":"2016-05-19 19:13:41"},{"topicid":52628016,"title":"14.98骂声一片，14.18也骂声一片。。。","lastreplydate":"2016-05-20 18:56:22","postusername":"恨屎不是饭","replycounts":136,"ispictopic":0,"bbsid":3968,"bbsname":"马自达CX-4论坛","postdate":"2016-05-20 11:56:17"},{"topicid":52615020,"title":"恭喜吉利！贺喜吉利！好消息","lastreplydate":"2016-05-20 19:03:52","postusername":"天道酬勤股道至简","replycounts":37,"ispictopic":1,"bbsid":3465,"bbsname":"帝豪GS论坛","postdate":"2016-05-19 22:00:49"},{"topicid":52621001,"title":"掰断交警手指 running白完！","lastreplydate":"2016-05-20 19:05:37","postusername":"年糕_518","replycounts":126,"ispictopic":1,"bbsid":100024,"bbsname":"上海论坛","postdate":"2016-05-20 07:40:46"}]
     */

    private ResultBean result;

    public int getReturncode() {
        return returncode;
    }

    public void setReturncode(int returncode) {
        this.returncode = returncode;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public ResultBean getResult() {
        return result;
    }

    public void setResult(ResultBean result) {
        this.result = result;
    }

    public static class ResultBean {
        private int pagecount;
        private int rowcount;
        private int pageindex;
        /**
         * topicid : 52622342
         * title : 北五环外环520重大交通事故！更新，途安车主只腿部轻伤
         * lastreplydate : 2016-05-20 19:01:58
         * postusername : 玻璃一般的透明
         * replycounts : 143
         * ispictopic : 1
         * bbsid : 100002
         * bbsname : 北京论坛
         * postdate : 2016-05-20 09:01:53
         */

        private List<ListBean> list;

        public int getPagecount() {
            return pagecount;
        }

        public void setPagecount(int pagecount) {
            this.pagecount = pagecount;
        }

        public int getRowcount() {
            return rowcount;
        }

        public void setRowcount(int rowcount) {
            this.rowcount = rowcount;
        }

        public int getPageindex() {
            return pageindex;
        }

        public void setPageindex(int pageindex) {
            this.pageindex = pageindex;
        }

        public List<ListBean> getList() {
            return list;
        }

        public void setList(List<ListBean> list) {
            this.list = list;
        }

        public static class ListBean {
            private int topicid;
            private String title;
            private String lastreplydate;
            private String postusername;
            private int replycounts;
            private int ispictopic;
            private int bbsid;
            private String bbsname;
            private String postdate;

            public int getTopicid() {
                return topicid;
            }

            public void setTopicid(int topicid) {
                this.topicid = topicid;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getLastreplydate() {
                return lastreplydate;
            }

            public void setLastreplydate(String lastreplydate) {
                this.lastreplydate = lastreplydate;
            }

            public String getPostusername() {
                return postusername;
            }

            public void setPostusername(String postusername) {
                this.postusername = postusername;
            }

            public int getReplycounts() {
                return replycounts;
            }

            public void setReplycounts(int replycounts) {
                this.replycounts = replycounts;
            }

            public int getIspictopic() {
                return ispictopic;
            }

            public void setIspictopic(int ispictopic) {
                this.ispictopic = ispictopic;
            }

            public int getBbsid() {
                return bbsid;
            }

            public void setBbsid(int bbsid) {
                this.bbsid = bbsid;
            }

            public String getBbsname() {
                return bbsname;
            }

            public void setBbsname(String bbsname) {
                this.bbsname = bbsname;
            }

            public String getPostdate() {
                return postdate;
            }

            public void setPostdate(String postdate) {
                this.postdate = postdate;
            }
        }
    }
}
