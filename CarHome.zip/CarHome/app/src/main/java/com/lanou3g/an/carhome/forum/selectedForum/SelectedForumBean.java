package com.lanou3g.an.carhome.forum.selectedForum;

import java.util.List;

/**
 * Created by anfeng on 16/5/19.
 */
public class SelectedForumBean {

    /**
     * message :
     * returncode : 0
     * result : {"pageindex":1,"pagecount":2346,"rowcount":46917,"list":[{"topicid":52304730,"title":"怀揣硬汉情结 哈弗H9购车用车分享","lastreplydate":"1天前","postusername":"智齿发言","replycounts":120,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g5/M08/83/A8/userphotos/2016/05/19/17/240180_wKgH21c9gYSAUzZ1AAE6v31rqII137.jpg","topictype":"精","views":27649,"postmemberid":0,"imgurl":"","bbsid":3298,"bbstype":"c","bbsname":"汇买车14486季"},{"topicid":52579783,"title":"一见钟情的选择 入手奔驰C 200 L","lastreplydate":"7小时前","postusername":"titanium2013","replycounts":13,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g14/M05/81/84/userphotos/2016/05/19/05/240180_wKgH1Vc83kuAC0PqAAEsgpdBYaI772.jpg","topictype":"精","views":1851,"postmemberid":0,"imgurl":"","bbsid":588,"bbstype":"c","bbsname":"行车点评5684季"},{"topicid":52308242,"title":"依然自信威武 海马S7 2.0L行车点评","lastreplydate":"2分钟前","postusername":"maomao10101314","replycounts":87,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g7/M0C/82/CC/userphotos/2016/05/19/16/240180_wKgHzlc9dBSABIE3AAEk15QNiQs270.jpg","topictype":"精","views":10002,"postmemberid":0,"imgurl":"","bbsid":3075,"bbstype":"c","bbsname":"行车点评5683季"},{"topicid":52255535,"title":"换挡顺滑空间大 奔驰R 320用车杂谈","lastreplydate":"1分钟前","postusername":"148277854","replycounts":503,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g7/M03/78/C6/userphotos/2016/05/10/21/240180_wKgH3Vcx6OqAYHXxAAE0RD1D7iE871.jpg","topictype":"精","views":140701,"postmemberid":0,"imgurl":"","bbsid":469,"bbstype":"c","bbsname":"行车点评5682季"},{"topicid":52164855,"title":"首要目标是安全 沃尔沃S60L提车记","lastreplydate":"8分钟前","postusername":"wtzkof98","replycounts":303,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g16/M13/75/00/userphotos/2016/05/08/10/240180_wKgH5lcupa-Afat6AAEknjR_3ec692.jpg","topictype":"精","views":81935,"postmemberid":0,"imgurl":"","bbsid":404,"bbstype":"c","bbsname":"汇买车14485季"},{"topicid":52502874,"title":"人中吕布马中赤兔 宝马328Li提车记","lastreplydate":"3秒前","postusername":"YaphetS7988","replycounts":567,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g16/M14/80/08/userphotos/2016/05/17/11/240180_wKjBx1c6kO-AfFngAAIE-Q1Wq6Q134.jpg","topictype":"精","views":154217,"postmemberid":0,"imgurl":"","bbsid":66,"bbstype":"c","bbsname":"汇买车14484季"},{"topicid":52551929,"title":"外观惊艳内饰豪华 全新思域购车记","lastreplydate":"1分钟前","postusername":"fbcaizh","replycounts":1020,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g22/M0E/63/C8/userphotos/2016/05/18/15/240180_wKgFW1c8FKeAVZTSAAEvjn0niV8666.jpg","topictype":"精","views":199846,"postmemberid":0,"imgurl":"","bbsid":9901135,"bbstype":"c","bbsname":"精挑细选4151季"},{"topicid":52181343,"title":"爱上这份原生态 自驾车穿越大风顶","lastreplydate":"6分钟前","postusername":"李贰娃","replycounts":255,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g14/M06/74/F9/userphotos/2016/05/09/00/240180_wKgH1VcvYxaAUY83AAE7ZNzRE4I304.jpg","topictype":"精","views":28070,"postmemberid":0,"imgurl":"","bbsid":3008,"bbstype":"c","bbsname":"西南游记2628季"},{"topicid":52276247,"title":"更舒适之选 传祺GA8 320T论坛首发","lastreplydate":"1分钟前","postusername":"小朱先生306","replycounts":510,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g8/M14/85/3A/userphotos/2016/05/18/21/240180_wKgH3lc8aUGAXGtxAAEtmDms260482.jpg","topictype":"精","views":61261,"postmemberid":0,"imgurl":"","bbsid":3782,"bbstype":"c","bbsname":"首发阵营299季"},{"topicid":52275719,"title":"沉稳气场足 金牛座2.0T至尊型提车","lastreplydate":"3分钟前","postusername":"麦田守望者啊","replycounts":348,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g7/M08/82/71/userphotos/2016/05/18/17/240180_wKgH3Vc8NRCALbVvAAE43TkYgB4229.jpg","topictype":"精","views":76799,"postmemberid":0,"imgurl":"","bbsid":3693,"bbstype":"c","bbsname":"汇买车14483季"},{"topicid":52490902,"title":"不弃不离的存在 奥拓1.0L使用心得","lastreplydate":"4分钟前","postusername":"冰冷之缘","replycounts":219,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g20/M08/62/AE/userphotos/2016/05/17/18/240180_wKgFVFc67WyAe2aLAAE5V6_-KEU910.jpg","topictype":"精","views":30692,"postmemberid":0,"imgurl":"","bbsid":872,"bbstype":"c","bbsname":"行车点评5681季"},{"topicid":48687148,"title":"量身定制的体验 科鲁兹脚垫安装记","lastreplydate":"22分钟前","postusername":"瓦房店g秋心不愁g","replycounts":71,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g11/M13/76/D2/userphotos/2016/05/09/17/240180_wKgH4VcwXVOAKZP1AAEyEaOSZdw848.jpg","topictype":"精","views":15135,"postmemberid":0,"imgurl":"","bbsid":657,"bbstype":"c","bbsname":"杂谈俱乐部602季"},{"topicid":51633486,"title":"理性分析做选择 瑞风S3选车用车记","lastreplydate":"21分钟前","postusername":"SDUNK仙道","replycounts":61,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g13/M07/5E/4F/userphotos/2016/04/20/15/240180_wKgH41cXL02AA9hqAAEdOoParsc849.jpg","topictype":"精","views":14495,"postmemberid":0,"imgurl":"","bbsid":3080,"bbstype":"c","bbsname":"汇买车14482季"},{"topicid":52149563,"title":"去往那片荒凉之地 单车自驾走向海","lastreplydate":"37分钟前","postusername":"kjdxwf618","replycounts":92,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g17/M10/6F/D9/userphotos/2016/05/08/16/240180_wKjBxlcu9gaADgnMAAFCdwAo-lE627.jpg","topictype":"精","views":18532,"postmemberid":0,"imgurl":"","bbsid":3872,"bbstype":"c","bbsname":"东北游记320季"},{"topicid":52277030,"title":"三年一轮回 美帝租赁奔驰GLE 350","lastreplydate":"51分钟前","postusername":"yaning2016","replycounts":156,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g20/M07/64/4F/userphotos/2016/05/19/00/240180_wKgFVFc8kaeACWqhAAFCsJ3xYgw259.jpg","topictype":"精","views":53559,"postmemberid":0,"imgurl":"","bbsid":3683,"bbstype":"c","bbsname":"海外购车1055季"},{"topicid":52275988,"title":"一曲经典老歌 第六代雅阁用车/改装","lastreplydate":"2分钟前","postusername":"nickpoon","replycounts":335,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g11/M01/82/96/userphotos/2016/05/18/23/240180_wKgH0lc8hb2AHV-8AAEhAwMdXzY661.jpg","topictype":"精","views":95848,"postmemberid":0,"imgurl":"","bbsid":78,"bbstype":"c","bbsname":"经典老车791季"},{"topicid":52276033,"title":"配置不输同级车 沃尔沃XC60选用记","lastreplydate":"14分钟前","postusername":"mcgrady162","replycounts":126,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g23/M05/64/AC/userphotos/2016/05/18/21/240180_wKgFXFc8bFWAQMx8AAEiLO7FnXw328.jpg","topictype":"精","views":25781,"postmemberid":0,"imgurl":"","bbsid":3411,"bbstype":"c","bbsname":"行车点评5680季"},{"topicid":52138801,"title":"心里有个草原 一路向北迷走海拉尔","lastreplydate":"12分钟前","postusername":"昊摄之徒1987","replycounts":85,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g7/M02/71/24/userphotos/2016/05/05/00/240180_wKgH3VcqHc-APFnxAAEvI_NiRz4223.jpg","topictype":"精","views":6544,"postmemberid":0,"imgurl":"","bbsid":100011,"bbstype":"a","bbsname":"华北游记1036季"},{"topicid":52480717,"title":"无与伦比的美丽 提雷克萨斯IS200t","lastreplydate":"3分钟前","postusername":"yylovemin2","replycounts":255,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g4/M00/7F/21/userphotos/2016/05/16/17/240180_wKjB01c5l8-ASrgkAAGLrMmjnyE440.jpg","topictype":"精","views":61861,"postmemberid":0,"imgurl":"","bbsid":201,"bbstype":"c","bbsname":"汇买车14481季"},{"topicid":52253187,"title":"实用舒适 全新途安L 280TSI初体验","lastreplydate":"2分钟前","postusername":"激情蓝2012","replycounts":139,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g18/M00/81/B4/userphotos/2016/05/18/19/240180_wKgH6Fc8TdiAONAyAAE_4MiVf_g943.jpg","topictype":"精","views":31391,"postmemberid":0,"imgurl":"","bbsid":9901333,"bbstype":"c","bbsname":"行车点评5679季"}]}
     */

    private String message;
    private int returncode;
    /**
     * pageindex : 1
     * pagecount : 2346
     * rowcount : 46917
     * list : [{"topicid":52304730,"title":"怀揣硬汉情结 哈弗H9购车用车分享","lastreplydate":"1天前","postusername":"智齿发言","replycounts":120,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g5/M08/83/A8/userphotos/2016/05/19/17/240180_wKgH21c9gYSAUzZ1AAE6v31rqII137.jpg","topictype":"精","views":27649,"postmemberid":0,"imgurl":"","bbsid":3298,"bbstype":"c","bbsname":"汇买车14486季"},{"topicid":52579783,"title":"一见钟情的选择 入手奔驰C 200 L","lastreplydate":"7小时前","postusername":"titanium2013","replycounts":13,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g14/M05/81/84/userphotos/2016/05/19/05/240180_wKgH1Vc83kuAC0PqAAEsgpdBYaI772.jpg","topictype":"精","views":1851,"postmemberid":0,"imgurl":"","bbsid":588,"bbstype":"c","bbsname":"行车点评5684季"},{"topicid":52308242,"title":"依然自信威武 海马S7 2.0L行车点评","lastreplydate":"2分钟前","postusername":"maomao10101314","replycounts":87,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g7/M0C/82/CC/userphotos/2016/05/19/16/240180_wKgHzlc9dBSABIE3AAEk15QNiQs270.jpg","topictype":"精","views":10002,"postmemberid":0,"imgurl":"","bbsid":3075,"bbstype":"c","bbsname":"行车点评5683季"},{"topicid":52255535,"title":"换挡顺滑空间大 奔驰R 320用车杂谈","lastreplydate":"1分钟前","postusername":"148277854","replycounts":503,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g7/M03/78/C6/userphotos/2016/05/10/21/240180_wKgH3Vcx6OqAYHXxAAE0RD1D7iE871.jpg","topictype":"精","views":140701,"postmemberid":0,"imgurl":"","bbsid":469,"bbstype":"c","bbsname":"行车点评5682季"},{"topicid":52164855,"title":"首要目标是安全 沃尔沃S60L提车记","lastreplydate":"8分钟前","postusername":"wtzkof98","replycounts":303,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g16/M13/75/00/userphotos/2016/05/08/10/240180_wKgH5lcupa-Afat6AAEknjR_3ec692.jpg","topictype":"精","views":81935,"postmemberid":0,"imgurl":"","bbsid":404,"bbstype":"c","bbsname":"汇买车14485季"},{"topicid":52502874,"title":"人中吕布马中赤兔 宝马328Li提车记","lastreplydate":"3秒前","postusername":"YaphetS7988","replycounts":567,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g16/M14/80/08/userphotos/2016/05/17/11/240180_wKjBx1c6kO-AfFngAAIE-Q1Wq6Q134.jpg","topictype":"精","views":154217,"postmemberid":0,"imgurl":"","bbsid":66,"bbstype":"c","bbsname":"汇买车14484季"},{"topicid":52551929,"title":"外观惊艳内饰豪华 全新思域购车记","lastreplydate":"1分钟前","postusername":"fbcaizh","replycounts":1020,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g22/M0E/63/C8/userphotos/2016/05/18/15/240180_wKgFW1c8FKeAVZTSAAEvjn0niV8666.jpg","topictype":"精","views":199846,"postmemberid":0,"imgurl":"","bbsid":9901135,"bbstype":"c","bbsname":"精挑细选4151季"},{"topicid":52181343,"title":"爱上这份原生态 自驾车穿越大风顶","lastreplydate":"6分钟前","postusername":"李贰娃","replycounts":255,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g14/M06/74/F9/userphotos/2016/05/09/00/240180_wKgH1VcvYxaAUY83AAE7ZNzRE4I304.jpg","topictype":"精","views":28070,"postmemberid":0,"imgurl":"","bbsid":3008,"bbstype":"c","bbsname":"西南游记2628季"},{"topicid":52276247,"title":"更舒适之选 传祺GA8 320T论坛首发","lastreplydate":"1分钟前","postusername":"小朱先生306","replycounts":510,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g8/M14/85/3A/userphotos/2016/05/18/21/240180_wKgH3lc8aUGAXGtxAAEtmDms260482.jpg","topictype":"精","views":61261,"postmemberid":0,"imgurl":"","bbsid":3782,"bbstype":"c","bbsname":"首发阵营299季"},{"topicid":52275719,"title":"沉稳气场足 金牛座2.0T至尊型提车","lastreplydate":"3分钟前","postusername":"麦田守望者啊","replycounts":348,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g7/M08/82/71/userphotos/2016/05/18/17/240180_wKgH3Vc8NRCALbVvAAE43TkYgB4229.jpg","topictype":"精","views":76799,"postmemberid":0,"imgurl":"","bbsid":3693,"bbstype":"c","bbsname":"汇买车14483季"},{"topicid":52490902,"title":"不弃不离的存在 奥拓1.0L使用心得","lastreplydate":"4分钟前","postusername":"冰冷之缘","replycounts":219,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g20/M08/62/AE/userphotos/2016/05/17/18/240180_wKgFVFc67WyAe2aLAAE5V6_-KEU910.jpg","topictype":"精","views":30692,"postmemberid":0,"imgurl":"","bbsid":872,"bbstype":"c","bbsname":"行车点评5681季"},{"topicid":48687148,"title":"量身定制的体验 科鲁兹脚垫安装记","lastreplydate":"22分钟前","postusername":"瓦房店g秋心不愁g","replycounts":71,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g11/M13/76/D2/userphotos/2016/05/09/17/240180_wKgH4VcwXVOAKZP1AAEyEaOSZdw848.jpg","topictype":"精","views":15135,"postmemberid":0,"imgurl":"","bbsid":657,"bbstype":"c","bbsname":"杂谈俱乐部602季"},{"topicid":51633486,"title":"理性分析做选择 瑞风S3选车用车记","lastreplydate":"21分钟前","postusername":"SDUNK仙道","replycounts":61,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g13/M07/5E/4F/userphotos/2016/04/20/15/240180_wKgH41cXL02AA9hqAAEdOoParsc849.jpg","topictype":"精","views":14495,"postmemberid":0,"imgurl":"","bbsid":3080,"bbstype":"c","bbsname":"汇买车14482季"},{"topicid":52149563,"title":"去往那片荒凉之地 单车自驾走向海","lastreplydate":"37分钟前","postusername":"kjdxwf618","replycounts":92,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g17/M10/6F/D9/userphotos/2016/05/08/16/240180_wKjBxlcu9gaADgnMAAFCdwAo-lE627.jpg","topictype":"精","views":18532,"postmemberid":0,"imgurl":"","bbsid":3872,"bbstype":"c","bbsname":"东北游记320季"},{"topicid":52277030,"title":"三年一轮回 美帝租赁奔驰GLE 350","lastreplydate":"51分钟前","postusername":"yaning2016","replycounts":156,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g20/M07/64/4F/userphotos/2016/05/19/00/240180_wKgFVFc8kaeACWqhAAFCsJ3xYgw259.jpg","topictype":"精","views":53559,"postmemberid":0,"imgurl":"","bbsid":3683,"bbstype":"c","bbsname":"海外购车1055季"},{"topicid":52275988,"title":"一曲经典老歌 第六代雅阁用车/改装","lastreplydate":"2分钟前","postusername":"nickpoon","replycounts":335,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g11/M01/82/96/userphotos/2016/05/18/23/240180_wKgH0lc8hb2AHV-8AAEhAwMdXzY661.jpg","topictype":"精","views":95848,"postmemberid":0,"imgurl":"","bbsid":78,"bbstype":"c","bbsname":"经典老车791季"},{"topicid":52276033,"title":"配置不输同级车 沃尔沃XC60选用记","lastreplydate":"14分钟前","postusername":"mcgrady162","replycounts":126,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g23/M05/64/AC/userphotos/2016/05/18/21/240180_wKgFXFc8bFWAQMx8AAEiLO7FnXw328.jpg","topictype":"精","views":25781,"postmemberid":0,"imgurl":"","bbsid":3411,"bbstype":"c","bbsname":"行车点评5680季"},{"topicid":52138801,"title":"心里有个草原 一路向北迷走海拉尔","lastreplydate":"12分钟前","postusername":"昊摄之徒1987","replycounts":85,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g7/M02/71/24/userphotos/2016/05/05/00/240180_wKgH3VcqHc-APFnxAAEvI_NiRz4223.jpg","topictype":"精","views":6544,"postmemberid":0,"imgurl":"","bbsid":100011,"bbstype":"a","bbsname":"华北游记1036季"},{"topicid":52480717,"title":"无与伦比的美丽 提雷克萨斯IS200t","lastreplydate":"3分钟前","postusername":"yylovemin2","replycounts":255,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g4/M00/7F/21/userphotos/2016/05/16/17/240180_wKjB01c5l8-ASrgkAAGLrMmjnyE440.jpg","topictype":"精","views":61861,"postmemberid":0,"imgurl":"","bbsid":201,"bbstype":"c","bbsname":"汇买车14481季"},{"topicid":52253187,"title":"实用舒适 全新途安L 280TSI初体验","lastreplydate":"2分钟前","postusername":"激情蓝2012","replycounts":139,"isclosed":0,"bigpic":"","smallpic":"http://club2.autoimg.cn/album/g18/M00/81/B4/userphotos/2016/05/18/19/240180_wKgH6Fc8TdiAONAyAAE_4MiVf_g943.jpg","topictype":"精","views":31391,"postmemberid":0,"imgurl":"","bbsid":9901333,"bbstype":"c","bbsname":"行车点评5679季"}]
     */

    private ResultBean result;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public int getReturncode() {
        return returncode;
    }

    public void setReturncode(int returncode) {
        this.returncode = returncode;
    }

    public ResultBean getResult() {
        return result;
    }

    public void setResult(ResultBean result) {
        this.result = result;
    }

    public static class ResultBean {
        private int pageindex;
        private int pagecount;
        private int rowcount;
        /**
         * topicid : 52304730
         * title : 怀揣硬汉情结 哈弗H9购车用车分享
         * lastreplydate : 1天前
         * postusername : 智齿发言
         * replycounts : 120
         * isclosed : 0
         * bigpic :
         * smallpic : http://club2.autoimg.cn/album/g5/M08/83/A8/userphotos/2016/05/19/17/240180_wKgH21c9gYSAUzZ1AAE6v31rqII137.jpg
         * topictype : 精
         * views : 27649
         * postmemberid : 0
         * imgurl :
         * bbsid : 3298
         * bbstype : c
         * bbsname : 汇买车14486季
         */

        private List<ListBean> list;

        public int getPageindex() {
            return pageindex;
        }

        public void setPageindex(int pageindex) {
            this.pageindex = pageindex;
        }

        public int getPagecount() {
            return pagecount;
        }

        public void setPagecount(int pagecount) {
            this.pagecount = pagecount;
        }

        public int getRowcount() {
            return rowcount;
        }

        public void setRowcount(int rowcount) {
            this.rowcount = rowcount;
        }

        public List<ListBean> getList() {
            return list;
        }

        public void setList(List<ListBean> list) {
            this.list = list;
        }

        public static class ListBean {
            private int topicid;
            private String title;
            private String lastreplydate;
            private String postusername;
            private int replycounts;
            private int isclosed;
            private String bigpic;
            private String smallpic;
            private String topictype;
            private int views;
            private int postmemberid;
            private String imgurl;
            private int bbsid;
            private String bbstype;
            private String bbsname;

            public int getTopicid() {
                return topicid;
            }

            public void setTopicid(int topicid) {
                this.topicid = topicid;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getLastreplydate() {
                return lastreplydate;
            }

            public void setLastreplydate(String lastreplydate) {
                this.lastreplydate = lastreplydate;
            }

            public String getPostusername() {
                return postusername;
            }

            public void setPostusername(String postusername) {
                this.postusername = postusername;
            }

            public int getReplycounts() {
                return replycounts;
            }

            public void setReplycounts(int replycounts) {
                this.replycounts = replycounts;
            }

            public int getIsclosed() {
                return isclosed;
            }

            public void setIsclosed(int isclosed) {
                this.isclosed = isclosed;
            }

            public String getBigpic() {
                return bigpic;
            }

            public void setBigpic(String bigpic) {
                this.bigpic = bigpic;
            }

            public String getSmallpic() {
                return smallpic;
            }

            public void setSmallpic(String smallpic) {
                this.smallpic = smallpic;
            }

            public String getTopictype() {
                return topictype;
            }

            public void setTopictype(String topictype) {
                this.topictype = topictype;
            }

            public int getViews() {
                return views;
            }

            public void setViews(int views) {
                this.views = views;
            }

            public int getPostmemberid() {
                return postmemberid;
            }

            public void setPostmemberid(int postmemberid) {
                this.postmemberid = postmemberid;
            }

            public String getImgurl() {
                return imgurl;
            }

            public void setImgurl(String imgurl) {
                this.imgurl = imgurl;
            }

            public int getBbsid() {
                return bbsid;
            }

            public void setBbsid(int bbsid) {
                this.bbsid = bbsid;
            }

            public String getBbstype() {
                return bbstype;
            }

            public void setBbstype(String bbstype) {
                this.bbstype = bbstype;
            }

            public String getBbsname() {
                return bbsname;
            }

            public void setBbsname(String bbsname) {
                this.bbsname = bbsname;
            }
        }
    }
}
