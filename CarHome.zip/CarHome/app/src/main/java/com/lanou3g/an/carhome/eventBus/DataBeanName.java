package com.lanou3g.an.carhome.eventBus;

/**
 * Created by anfeng on 16/5/28.
 */
public class DataBeanName {
    private String name;

    public DataBeanName(String name) {
        this.name = name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
